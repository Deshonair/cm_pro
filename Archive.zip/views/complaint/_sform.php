<fieldset>
	<legend>Customer Account Search</legend>
	<div>
		<label> Search By</label>
    		<select name="post[search_by]" >
                <option value="accountNumber">Account Number</option>
                <option value="officerName">Officer Name</option>											
          	</select>
		<input name="post[search]" size="40" type="text" maxlength="16" />
		<input type="submit" value="search" />
	</div>
</fieldset>