<?php  $branches0=find_branches(); $branches1=find_branches(); $atm0=find_atms(); $atm1=find_atms(); ?>
 <fieldset>
   <legend> Customer Detail </legend>

           <table width="100%" border="0">
             <tr>
               <td width="15%">Customer Name</td>
               <td width="23%"><input name="post[customerName]" size="20" type="text" value="" /></td>
               <td width="12%">Account Number</td>
               <td width="18%"><input name="post[accountNumber]" size="17" maxlength="16" type="text" value="" /></td>
               <td width="12%">Reporting Branch</td>
               <td width="20%"><select name="post[reportingBranch]">
                   <option value=""></option>
                   <?php foreach( $branches0 as $post => $branch){ echo '<option value="'.$branch['branchId'].'">'.$branch['name'].' </option>';}; ?>
               </select></td>
             </tr>

             <tr>
               <td width="15%">Officer Name</td>
               <td width="23%"><input name="post[officerName]" size="20" maxlength="16" type="text" value="" /></td>
               <td width="12%">Card Type</td>
               <td width="18%"><select name="post[cardType]">
                   <option value=""></option>
                   <option value="visa"> VISA </option>
                   <option value="proprietary"> PROPRIETARY </option>
               </select></td>
               <td width="12%">Customer Branch</td>
               <td width="20%"><select name="post[customerBranch]">
                   <option value=""></option>
                   <?php foreach( $branches1 as $post => $branch){ echo '<option value="'.$branch['branchId'].'">'.$branch['name'].' </option>';}; ?>
               </select></td>
             </tr>
             <tr>
               <td width="15%">Customer Phone</td>
               <td width="23%"><input name="post[phone]" size="12" maxlength="10" type="text" value="" /></td>
               <td width="12%">Complaint Date</td>
               <td width="18%"><input name="post[complaintDate]" type="text" value="" size="12" readonly="readonly"/>
                   <script language="JavaScript" type="text/javascript">
							new tcal ({
								// form name
								'formname': 'ccom',
								// input name
								'controlname': 'post[complaintDate]'
							});
						</script>
               </td>
               <td width="12%">&nbsp;</td>
               <td width="20%">&nbsp;</td>
             </tr>
 </table>

 </fieldset>
</BR>
  <fieldset>
   <legend> Card Detail </legend>

           <table width="100%" border="0">
             <tr>
               <td width="15%"> Complaint</td>
               <td width="23%"><select name="post[cardComplaint]">
                      <option value=""></option>
					  <option value="Card Capture"> Card Capture </option>
                      <option value="Pin Forgotten"> Pin Forgotten </option>
					  <option value="Account Addition"> Account Addition </option>
					  <option value="Limit Update"> Limit Update </option>
					  <option value="Others"> Others </option>
               </select></td>
               <td width="12%">Which ATM</td>
               <td width="18%"><select name="post[cardAtm]">
                   <option value=""></option>
                   <?php foreach( $atm0 as $post => $atm){ echo '<option value="'.$atm['code'].'">'.$atm['code']."_".$atm['name'].' </option>';}; ?>
               </select></td>
               <td width="12%">Link Acc #1</td>
               <td width="20%"><input name="post[account1]" size="18" maxlength="16" type="text" value="" /></td>
             </tr>

             <tr>
               <td width="15%">Action Taken</td>
               <td width="23%"><input name="post[actionTaken]" size="20" type="text" value="" /></td>
               <td width="12%">Amount Involved</td>
               <td width="18%"><input name="post[cardAmt]" size="17" maxlength="12" type="text" value="" /></td>
               <td width="12%">Link Acc #2</td>
               <td width="20%"><input name="post[account2]" size="18" maxlength="16" type="text" value="" /></td>
             </tr>
             <tr>
               <td width="15%">&nbsp;</td>
               <td width="23%">&nbsp;</td>
               <td width="12%">What Date</td>
               <td width="18%"><input name="post[cardComDate]" type="text" value="" size="12" readonly=""/>
               <script language="JavaScript" type="text/javascript">
							new tcal ({
								// form name
								'formname': 'ccom',
								// input name
								'controlname': 'post[cardComDate]'
							});
						</script></td>
               <td width="12%">What Time</td>
               <td width="20%"><select name="post[cardTimeHr]">
                     <option value=""></option>
                     <option value="00">00</option>
                     <option value="01">01</option>
                     <option value="02">02</option>
                     <option value="03">03</option>
                     <option value="04">04</option>
                     <option value="05">05</option>
                     <option value="06">06</option>
                     <option value="07">07</option>
                     <option value="08">08</option>
                     <option value="09">09</option>
                     <option value="10">10</option>
                     <option value="11">11</option>
                     <option value="12">12</option>
                     <option value="13">13</option>
                     <option value="14">14</option>
                     <option value="15">15</option>
                     <option value="16">16</option>
                     <option value="17">17</option>
                     <option value="18">18</option>
                     <option value="19">19</option>
                     <option value="20">20</option>
                     <option value="21">21</option>
                     <option value="22">22</option>
                     <option value="23">23</option>
                   </select>
                 HR
                 <select name="post[cardTimeMin]">
    <option value=""></option>
    <option value="00">00</option>
    <option value="01">01</option>
    <option value="02">02</option>
    <option value="03">03</option>
    <option value="04">04</option>
    <option value="05">05</option>
    <option value="06">06</option>
    <option value="07">07</option>
    <option value="08">08</option>
    <option value="09">09</option>
    <option value="10">10</option>
    <option value="11">11</option>
    <option value="12">12</option>
    <option value="13">13</option>
    <option value="14">14</option>
    <option value="15">15</option>
    <option value="16">16</option>
    <option value="17">17</option>
    <option value="18">18</option>
    <option value="19">19</option>
    <option value="20">20</option>
    <option value="21">21</option>
    <option value="22">22</option>
    <option value="23">23</option>
    <option value="24">24</option>
    <option value="25">25</option>
    <option value="26">26</option>
    <option value="27">27</option>
    <option value="28">28</option>
    <option value="29">29</option>
    <option value="30">30</option>
    <option value="31">31</option>
    <option value="32">32</option>
    <option value="33">33</option>
    <option value="34">34</option>
    <option value="35">35</option>
    <option value="36">36</option>
    <option value="37">37</option>
    <option value="38">38</option>
    <option value="39">39</option>
    <option value="40">40</option>
    <option value="41">41</option>
    <option value="42">42</option>
    <option value="43">43</option>
    <option value="44">44</option>
    <option value="45">45</option>
    <option value="46">46</option>
    <option value="47">47</option>
    <option value="48">48</option>
    <option value="49">49</option>
    <option value="50">50</option>
    <option value="51">51</option>
    <option value="52">52</option>
    <option value="53">53</option>
    <option value="54">54</option>
    <option value="55">55</option>
    <option value="56">56</option>
    <option value="57">57</option>
    <option value="58">58</option>
    <option value="59">59</option>
</select>
               MIN</td>
             </tr>
  </table>
 </fieldset>

 </BR>

  <fieldset>
   <legend> Cash Detail </legend>

           <table width="100%" border="0">
             <tr>
               <td width="15%">Cash Complaint</td>
               <td colspan="2"><select name="post[cashComplaint]">
                      <option value=""></option>
					  <option value="Cash Retracted"> Cash Retracted </option>
					  <option value="Multiple Debit"> Multiple Debit </option>
					  <option value="Cash not dispensed but Acc Debited"> Cash not dispensed but Acc Debited </option>
					  <option value="Others"> Others </option>
                    </select></td>
               <td width="18%">&nbsp;</td>
               <td width="12%">&nbsp;</td>
               <td width="20%">&nbsp;</td>
             </tr>

             <tr>
               <td width="15%">Amount Involved</td>
               <td width="23%"><input name="post[cashAmt]" size="12" maxlength="12" type="text" value="" /></td>
               <td width="12%">Which ATM</td>
               <td width="18%"><select name="post[cashAtm]">
                   <option value=""></option>
                   <?php foreach( $atm1 as $post => $atm){ echo '<option value="'.$atm['code'].'">'.$atm['name'].' </option>';}; ?>
               </select></td>
               <td width="12%"> Bank</td>
               <td width="20%"><select name="post[customerBank]">
                   <option value=""></option>
                   <option value="ADB"> ADB </option>
				                      <option value="BARCLAYS"> BARCLAYS </option>
				                      <option value="CAL"> CAL </option>
				                      <option value="STANDARD CHARTERED"> STANDARD CHARTERED </option>
				                      <option value="ZENITH"> ZENITH </option>
				                      <option value="ECOBANK"> ECOBANK </option>
				                      <option value="ACCESS BANK"> ACCESS BANK </option>
				                      <option value="FEDELITY"> FIDELITY </option>
				                      <option value="GT BANK"> GT BANK </option>
				                      <option value="STANBIC"> STANBIC </option>
				                      <option value="SG-SSB"> SG-SSB </option>
				                      <option value="GCB"> GCB </option>
				                      <option value="UT BANK"> UT BANK </option>
				                      <option value="UNIBANK"> UNIBANK </option>
				                      <option value="AMALGAMATED BANK"> AMALGAMATED BANK </option>
				                      <option value="PRUDENTIAL"> PRUDENTIAL </option>
				                      <option value="ENERGY BANK"> ENERGY BANK </option>
				                      <option value="UNITED BANK FOR AFRICA"> UNITED BANK FOR AFRICA </option>
				                      <option value="ICB"> ICB </option>
				                      <option value="NIB"> NIB </option>
				                      <option value="MERCHANT BANK"> MERCHANT BANK </option>
				                      <option value="APEX"> APEX </option>
				                      <option value="FIRST ATLANTIC"> FIRST ATLANTIC </option>
                   <option value="FOREIGN"> FOREIGN </option>
               </select></td>
             </tr>
             <tr>
               <td width="15%">RECEIPT #</td>
               <td width="23%"><input name="post[receiptNo]" size="12" maxlength="16" type="text" value="" /></td>
               <td width="12%">What Date</td>
               <td width="18%"><input name="post[cashComDate]" type="text" value="" size="12" readonly=""/>
                   <script language="JavaScript" type="text/javascript">
							new tcal ({
								// form name
								'formname': 'ccom',
								// input name
									'controlname': 'post[cashComDate]'
							});
						</script></td>
               <td width="12%">What Time</td>
               <td width="20%"><select name="post[cashTimeHr]">
                     <option value=""></option>
                     <option value="00">00</option>
                     <option value="01">01</option>
                     <option value="02">02</option>
                     <option value="03">03</option>
                     <option value="04">04</option>
                     <option value="05">05</option>
                     <option value="06">06</option>
                     <option value="07">07</option>
                     <option value="08">08</option>
                     <option value="09">09</option>
                     <option value="10">10</option>
                     <option value="11">11</option>
                     <option value="12">12</option>
                     <option value="13">13</option>
                     <option value="14">14</option>
                     <option value="15">15</option>
                     <option value="16">16</option>
                     <option value="17">17</option>
                     <option value="18">18</option>
                     <option value="19">19</option>
                     <option value="20">20</option>
                     <option value="21">21</option>
                     <option value="22">22</option>
                     <option value="23">23</option>
                   </select>
                 HR
  <select name="post[cashTimeMin]">
    <option value=""></option>
    <option value="00">00</option>
    <option value="01">01</option>
    <option value="02">02</option>
    <option value="03">03</option>
    <option value="04">04</option>
    <option value="05">05</option>
    <option value="06">06</option>
    <option value="07">07</option>
    <option value="08">08</option>
    <option value="09">09</option>
    <option value="10">10</option>
    <option value="11">11</option>
    <option value="12">12</option>
    <option value="13">13</option>
    <option value="14">14</option>
    <option value="15">15</option>
    <option value="16">16</option>
    <option value="17">17</option>
    <option value="18">18</option>
    <option value="19">19</option>
    <option value="20">20</option>
    <option value="21">21</option>
    <option value="22">22</option>
    <option value="23">23</option>
    <option value="24">24</option>
    <option value="25">25</option>
    <option value="26">26</option>
    <option value="27">27</option>
    <option value="28">28</option>
    <option value="29">29</option>
    <option value="30">30</option>
    <option value="31">31</option>
    <option value="32">32</option>
    <option value="33">33</option>
    <option value="34">34</option>
    <option value="35">35</option>
    <option value="36">36</option>
    <option value="37">37</option>
    <option value="38">38</option>
    <option value="39">39</option>
    <option value="40">40</option>
    <option value="41">41</option>
    <option value="42">42</option>
    <option value="43">43</option>
    <option value="44">44</option>
    <option value="45">45</option>
    <option value="46">46</option>
    <option value="47">47</option>
    <option value="48">48</option>
    <option value="49">49</option>
    <option value="50">50</option>
    <option value="51">51</option>
    <option value="52">52</option>
    <option value="53">53</option>
    <option value="54">54</option>
    <option value="55">55</option>
    <option value="56">56</option>
    <option value="57">57</option>
    <option value="58">58</option>
    <option value="59">59</option>
</select>
  MIN</td>
             </tr>
  </table>

 </fieldset>

  </BR>

  <fieldset>
   <legend> Comments </legend>

           <table width="100%" border="0">
             <tr>
               <td><input name="post[comment]" size="90" type="text" value="" /></td>
			   <td>&nbsp;</td>
			   <td><input name="post[user_id]" value="<?php echo $_SESSION['user']['id']; ?>" type="hidden" />
          			<input type="submit" value="submit" /></td>
             </tr>
		   </table>

 </fieldset>