<div id="navigator">
<form action="<?php echo APP_ROOT.DS; ?>complaint/edit" method="post" enctype="multipart/form-data" name="ccom" >

     <?php include('_formComplaintComment.php');  ?> 

</form>
</div>