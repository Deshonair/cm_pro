<div id="navigator">
<form action="<?php echo APP_ROOT.DS; ?>complaint/create" onsubmit="return cvalidateForm()" method="post" enctype="multipart/form-data" name="ccom" >

     <?php include('_formComplaint.php');  ?> 

</form>
</div>