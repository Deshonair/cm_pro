<div id="navigator">
<form action="<?php echo APP_ROOT.DS; ?>complaint/searchc" method="post">

     <?php include('_sform.php');  ?> 

</form>
</div>