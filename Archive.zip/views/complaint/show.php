<div id="navigator" > 

		<div id="pagination" align="right">
	
		<?php if(($page - 1) <= $total_pages && $page !=1): ?> 

			<a href="<?php echo APP_ROOT.DS; ?>complaint/index/page/1"><img src="<?php echo IMG;?>icons/first.gif" title="first"/></a>
			&nbsp;&nbsp;
			<a href="<?php echo APP_ROOT.DS; ?>complaint/index/page/<?php echo $page - 1; ?>"><img src="<?php echo IMG;?>icons/prev.gif" title="previous"/></a>
			
		<?php endif; ?>
		
		
		<?php if(($page + 1) <= $total_pages): ?>

			<a href="<?php echo APP_ROOT.DS; ?>complaint/index/page/<?php echo $page + 1; ?>"><img src="<?php echo IMG;?>icons/next.gif" title="next"/></a>
			&nbsp;&nbsp;
			<a href="<?php echo APP_ROOT.DS; ?>complaint/index/page/<?php echo $total_pages; ?>" ><img src="<?php echo IMG;?>icons/last.gif" title="last" /></a>
			<?php echo '&nbsp;&nbsp;&nbsp;&nbsp;Page&nbsp;'.$page.'&nbsp;of&nbsp;'.$total_pages ?>

		<?php endif; ?>

		</div>
	
	<table width="100%" cellpadding="5px">
		<tr> 
			<th>Customer</th>
			<th>Account</th>
			<th>Reporting Branch</th>
			<th>Card Type</th>
			<th>Complaint</th>
			<th>Status</th>
			<th>Date</th>			
			<th align="center">Action</th>
		</tr>
	
	<?php

		if(!$post)
		{
			echo "Find Complaint Failed";
		}
		else
		{
			foreach( $post['result'] as $posts => $card){
				include('_postc.php');
			}
		}
	?>

	</table>

		<div id="pagination" align="right">
	
		<?php if(($page - 1) <= $total_pages && $page !=1): ?> 

			<a href="<?php echo APP_ROOT.DS; ?>complaint/index/page/1"><img src="<?php echo IMG;?>icons/first.gif" title="first"/></a>
			&nbsp;&nbsp;
			<a href="<?php echo APP_ROOT.DS; ?>complaint/index/page/<?php echo $page - 1; ?>"><img src="<?php echo IMG;?>icons/prev.gif" title="previous"/></a>
			
		<?php endif; ?>
		
		
		<?php if(($page + 1) <= $total_pages): ?>

			<a href="<?php echo APP_ROOT.DS; ?>complaint/index/page/<?php echo $page + 1; ?>"><img src="<?php echo IMG;?>icons/next.gif" title="next"/></a>
			&nbsp;&nbsp;
			<a href="<?php echo APP_ROOT.DS; ?>complaint/index/page/<?php echo $total_pages; ?>" ><img src="<?php echo IMG;?>icons/last.gif" title="last" /></a>
			<?php echo '&nbsp;&nbsp;&nbsp;&nbsp;Page&nbsp;'.$page.'&nbsp;of&nbsp;'.$total_pages ?>

		<?php endif; ?>

		</div>
</div>