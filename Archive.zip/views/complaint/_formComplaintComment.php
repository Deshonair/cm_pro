<?php  $post=$complaint['result'][0]; $atm0=find_atms(); $atm1=find_atms(); ?>
 <fieldset>
   <legend> Customer Detail </legend>

           <table width="100%" border="0">
             <tr>
               <td width="15%">Customer Name</td>
               <td width="23%">| <?php echo $post['customerName'] ?></td>
               <td width="12%">Account Number</td>
               <td width="18%">| <?php echo $post['accountNumber'] ?></td>
               <td width="12%">Reporting Branch</td>
               <td width="20%">| <?php echo $post['reportingBranch'] ?></td>
             </tr>

             <tr>
               <td width="15%">Officer Name</td>
               <td width="23%">| <?php echo $post['officerName'] ?></td>
               <td width="12%">Card Type</td>
               <td width="18%">| <?php echo $post['cardType'] ?></td>
               <td width="12%">Customer Branch</td>
               <td width="20%">| <?php echo $post['customerBranch'] ?></td>
             </tr>
             <tr>
               <td width="15%">Customer Phone</td>
               <td width="23%">| <?php echo $post['phone'] ?></td>
               <td width="12%">Complaint Date</td>
               <td width="18%">| <?php echo $post['createDate'] ?></td>
               <td width="12%">&nbsp;</td>
               <td width="20%">&nbsp;</td>
             </tr>
 </table>

 </fieldset>
</BR>
  <fieldset>
   <legend> Card Detail </legend>

           <table width="100%" border="0">
             <tr>
               <td width="15%"> Complaint</td>
               <td width="23%">| <?php echo $post['cardComplaint'] ?></td>
               <td width="12%">Which ATM</td>
               <td width="18%">| <?php echo $post['cardAtm'] ?></td>
               <td width="12%">Link Acc #1</td>
               <td width="20%">| <?php echo $post['account1'] ?></td>
             </tr>

             <tr>
               <td width="15%">Action Taken</td>
               <td width="23%">| <?php echo $post['actionTaken'] ?></td>
               <td width="12%">Amount Involved</td>
               <td width="18%">| <?php echo $post['cardAmt'] ?></td>
               <td width="12%">Link Acc #2</td>
               <td width="20%">| <?php echo $post['account2'] ?></td>
             </tr>
             <tr>
               <td width="15%">&nbsp;</td>
               <td width="23%">&nbsp;</td>
               <td width="12%">What Date</td>
               <td width="18%">| <?php echo $post['cardIssueDateTime'] ?></td>
               <td width="12%">&nbsp;</td>
               <td width="20%">&nbsp;</td>
             </tr>
  </table>
 </fieldset>

 </BR>

  <fieldset>
   <legend> Cash Detail </legend>

           <table width="100%" border="0">
             <tr>
               <td width="15%">Cash Complaint</td>
               <td colspan="2">| <?php echo $post['cashComplaint'] ?></td>
               <td width="18%">&nbsp;</td>
               <td width="12%">&nbsp;</td>
               <td width="20%">&nbsp;</td>
             </tr>

             <tr>
               <td width="15%">Amount Involved</td>
               <td width="23%">| <?php echo $post['cashAmt'] ?></td>
               <td width="12%">Which ATM</td>
               <td width="18%">| <?php echo $post['cashAtm'] ?></td>
               <td width="12%"> Bank</td>
               <td width="20%">| <?php echo $post['customerBank'] ?></td>
             </tr>
             <tr>
               <td width="15%">RECEIPT #</td>
               <td width="23%">| <?php echo $post['receiptNo'] ?></td>
               <td width="12%">What Date</td>
               <td width="18%">| <?php echo $post['cashIssueDateTime'] ?></td>
               <td width="12%">&nbsp;</td>
               <td width="20%">&nbsp;</td>
             </tr>
  </table>

 </fieldset>
 
  </BR>

  <fieldset>
   <legend> Comments </legend>

           <table width="100%" border="0">
             <tr>
               <td>&nbsp;</td>
			   <td>| <?php echo $post['comment'] ?></td>
			   <td>&nbsp;</td>
             </tr>
			 <tr>
               <td>&nbsp;</td>
			   <td><input name="post[comment]" size="90" type="text" value="" /></td>
			   <td><input name="post[id]" value="<?php echo $post['id'] ?>" type="hidden" />
			       <input name="post[userName]" value="<?php echo $_SESSION['user']['userName'] ?>" type="hidden" />
          			<input type="submit" value="GO" /></td>
             </tr>
		   </table>

 </fieldset>