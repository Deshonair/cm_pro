<?php
	echo	
	  "<tr>
			<td>".$card['customerName']."</td>
			<td>".$card['accountNumber']."</td>
			<td>".$card['reportingBranch']."</td>
			<td>".$card['cardType']."</td>
			<td>".$card['cardComplaint']." <> ".$card['cashComplaint']."</td>
			<td>".$card['status']."</td>
			<td>".$card['createDate']."</td>
			<td align='center'>
";

if($_SESSION['user']['accessLevel']<1)
	{ echo "
				<a href='".APP_ROOT.DS."complaint".DS.$card['id'].DS."close' title='Resolved'>
	  				<img src='".IMG."icons/yes.gif' />
				</a> &nbsp;";
	}

	echo"
				<a href='".APP_ROOT.DS."complaint".DS.$card['id'].DS."delete' title='Delete'>
	  				<img src='".IMG."icons/no.gif' />
				</a> &nbsp;

	  			<a href='".APP_ROOT.DS."complaint".DS.$card['id'].DS."viewc' title='View'>
					<img src='".IMG."icons/edit.gif' />
				</a>

	  			<a href='".APP_ROOT.DS."complaint' title='OK'>
					<img src='".IMG."icons/next.gif' />
				</a>
			</td>
	   </tr>";
?>