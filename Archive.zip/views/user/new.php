<div id="navigator">
<form action="<?php echo APP_ROOT.DS; ?>user/create" method="post">

     <?php include('_form.php');  ?> 

</form>
</div>