<?php

	echo	
	  "<tr> 
			<td>".$user['user']."</td>
			<td>".$user['action']."</td>
			<td>".$user['page']."</td>
			<td>".$user['ip']."</td>
			<td>".$user['visitedDate']."</td>
	   </tr>";
?>