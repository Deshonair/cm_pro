 <fieldset>
	<legend> User Details </legend>
	
		 <div>
			 <br /> &emsp;&emsp;
             <label> Username </label> 
             &emsp;&emsp;&emsp;
			 <input name="post[userName]" type="text" 
             	value="<?php if(isset($post['userName'])) echo $post['userName'];  ?>" size="40" /> 
			</div>
	
		 <div>
			<br />&emsp;&emsp;
            <label> Password </label>
            &emsp;&emsp;&emsp;
			<input name="post[password]" type="password" value="<?php if(isset($post['password'])) echo $post['password'];  ?>" size="40" readonly />
		 </div>
         
		 <div> 
			<br />&emsp;&emsp;
            <label> LastName </label>
            &emsp;&emsp;&emsp;
			<input name="post[lastName]" type="text" value="<?php if(isset($post['lastName'])) echo $post['lastName'];  ?>" size="40" />
		 </div>
	
		 <div>
			<br />&emsp;&emsp;
            <label> OtherNames </label>
            &emsp;&emsp;
			<input name="post[otherNames]" type="text" value="<?php if(isset($post['otherNames'])) echo $post['otherNames'];  ?>" size="40" />
		 </div>

		 <div>
			<br />&emsp;&emsp;
            <label> Enable </label>
			&emsp;&emsp;&emsp;&emsp;&emsp;
            <select name="post[accountStatus]" >
  
                <option value="0"> - Disable</option>
                <option value="1"> - Enable</option>			
                                    
            </select>
		 </div>
	
		 <div>
			<br />&emsp;&emsp;
            <label> Access Level </label>
            &emsp;&emsp;
            <select name="post[accessLevel]" >
 
                <option value="9"> - Branch User</option>
                <option value="0"> - Administrator</option>
                                    
            </select>
		 </div><br />
			<br />&emsp;&emsp;
            <input type="submit" value="submit" />
			<input name="post[id]" value="<?php echo $post['id'];  ?>" type="hidden" />
            <br /><br />
 </fieldset>