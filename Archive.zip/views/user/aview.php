<div id="navigator" > 
	
<table width="100%" cellpadding="5px">
	<tr>
	  <th align='left'>Username</th>
	  <th align='left'>Action</th>
	  <th align='left'>Page Visited</th>
	  <th>Machine Used</th>
	  <th>Visited Date</th>
    </tr>
	
	<?php

		if(!$post)
		{
			echo "View User Audit Log Failed";
		}
		else
		{
			foreach( $post['result'] as $posts => $user){
				include('_apost.php');
			}
		}
	?>
	
	
	</table>
	
		<div id="pagination" align="right">
		
			<?php if((@$page - 1) <= @$total_pages && $page !=1): ?> 

				<a href="<?php echo APP_ROOT.DS; ?>user/<?php echo $params['id'] ?>/aview/page/1"><img src="<?php echo IMG;?>icons/first.gif" /></a>
				<a href="<?php echo APP_ROOT.DS; ?>user/<?php echo $params['id'] ?>/aview/page/<?php echo $page - 1; ?>"><img src="<?php echo IMG;?>icons/prev.gif" /></a>
			
			<?php endif; ?>
			
			
			<?php if((@$page + 1) <= @$total_pages): ?>

				<a href="<?php echo APP_ROOT.DS; ?>user/<?php echo $params['id'] ?>/aview/page/<?php echo $page + 1; ?>"><img src="<?php echo IMG;?>icons/next.gif" /></a>
				<a href="<?php echo APP_ROOT.DS; ?>user/<?php echo $params['id'] ?>/aview/page/<?php echo $total_pages; ?>"><img src="<?php echo IMG;?>icons/last.gif" /></a>
				<?php echo '&nbsp;&nbsp;Page&nbsp;'.$page.'&nbsp;of&nbsp;'.$total_pages ?>

			<?php endif; ?>

		</div>

</div>