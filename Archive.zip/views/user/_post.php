<?php

	echo	
	  "<tr> 
			<td><a style='color:#68b168;margin-left:20px' href='".APP_ROOT.DS."user".DS.$user['id'].DS."aview' >"
			.$user['userName']."</a></td>
			<td>".$user['otherNames']."</td>
			<td>".$user['lastName']."</td>
			<td align='center'>";
				if($user['loginStatus']==1)
					echo "<img src='".IMG."icons/yes.gif' />";
				else
					echo "<img src='".IMG."icons/no.gif' />";
	echo	"</td>
			<td align='center'>".$user['logonDate']."</td>
			<td align='center'>".$user['lastVisit']."</td>
			<td align='center'>";
				if($user['accountStatus']==1)
					echo "<img src='".IMG."icons/enable.gif' />";
				else
					echo "<img src='".IMG."icons/disable.gif' />";
	echo	"</td>
			<td align='center'>".$user['accessLevel']."</td>
			<td align='center'>
				<a href='".APP_ROOT.DS."user".DS.$user['id'].DS."edit' ><img src='".IMG."icons/edit.gif' /></a>
				<a href='".APP_ROOT.DS."user".DS.$user['id'].DS."delete' ><img src='".IMG."icons/delete.gif' /></a>
			</td>
	   </tr>";
?>