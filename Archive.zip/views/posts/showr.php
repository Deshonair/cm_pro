<div id="navigator" > 
	
	<table width="100%" cellpadding="5px">
		<tr> 
			<th>Customer</th>
			<th>Account</th>
			<th>Mobile Phone</th>
			<th>Request</th>
			<th>Card Type</th>
			<th>Status</th>
			<th>Email</th>
			<th>RequestDate</th>
			<th align="center">Action</th>
		</tr>
	
	<?php

		if(!$post)
		{
			echo "Find CardRequest Failed";
		}
		else
		{
			foreach( $post['result'] as $posts => $card){
				include('_postr.php');
			}
		}
	?>

	</table>

</div>