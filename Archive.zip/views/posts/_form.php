 <fieldset>
	<legend>Customer Account</legend>
	
		 <div>
			 <br /> &nbsp;&nbsp;&nbsp;
             <label> Customer Name </label> 
             &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			 <input name="post[customerName]" type="text" value="<?php echo $post['result'][0]['customerName'];  ?>" size="40" readonly="readonly" />
			</div>
	
		 <div>
			&nbsp;&nbsp;&nbsp;
            <label> Account Number </label>
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			<input name="post[accountNumber]" type="text" value="<?php echo $post['result'][0]['accountNumber'];  ?>" size="40" readonly="readonly" />
		 </div>
	
		 <div>
			&nbsp;&nbsp;&nbsp;
            <label> Card Number </label>
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			<input name="post[cardNumber]" type="text" value="<?php echo $post['result'][0]['cardNumber'];  ?>" size="40" readonly="readonly" />
		 </div>
	
		 <div>
			&nbsp;&nbsp;&nbsp;
            <label> Production Date </label>
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            <input name="post[productionDate]" type="text" value="<?php echo $post['result'][0]['productionDate'];  ?>" size="40" readonly="readonly" />
		 </div>
	
		 <div>
			&nbsp;&nbsp;&nbsp;
            <label> Dispatch Date </label>
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            <input name="post[dispatchDate]" type="text" value="<?php echo $post['result'][0]['dispatchDate'];  ?>" size="40" readonly="readonly" />
		 </div>
<?php if(!isset($params['var'])): ?>	
		 <div>
			&nbsp;&nbsp;&nbsp;
            <label> Pickup Date </label>
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            <input name="post[pickupDate]" type="text" value="<?php echo $post['result'][0]['pickupDate'];  ?>" size="40" readonly="readonly" />
		 </div>
	
		 <div>
			&nbsp;&nbsp;&nbsp;
            <label> Pickup Branch </label>
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            <select name="post[pickupBranch]" >
  
                <option value=""></option>
					<?php foreach ($branches as $branch => $bran) : ?>
                    <option value="<?php echo $bran['branchId']; ?>"><?php echo $bran['name']; ?></option>
                    <?php endforeach ?>
                                    
            </select>
		 </div><br />
			&nbsp;&nbsp;&nbsp;
            <input type="submit" value="submit" />
         
<?php endif; ?>
<?php if(isset($params['var']) && $params['var']=="pickup"): ?>
  &nbsp;&nbsp;&nbsp;
  <label> Pickup Date </label>
  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
  <input type="submit" value="Pick Up" />
  <input name="post[var]" value="<?php echo $params['var']; ?>" type="hidden" />
<?php endif; ?>
			<input name="post[id]" value="<?php echo $post['result'][0]['id'];  ?>" type="hidden" />
            <br /><br />
 </fieldset>