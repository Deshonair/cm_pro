 <fieldset>
   <legend>File Upload</legend>

		<div> 
           <br /> &nbsp;&nbsp;&nbsp;
		   <label> File Name </label>
           &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;
           <input name="post[filename]" size="40" type="file" value="" />
		</div>

		<div><br />
		    &nbsp;&nbsp;&nbsp;
            <label> Production Date </label>
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            <input name="post[productionDate]" size="40" type="text" value="" />
			<script language="JavaScript">
				new tcal ({
					// form name
					'formname': 'cardUpload',
					// input name
					'controlname': 'post[productionDate]'
				});
			</script>
		</div>
         
         <div><br />
		   &nbsp;&nbsp;&nbsp;
           <label> Card Request Type </label>
		   &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
           <select name="post[operationType]">
                      <option value=""></option>
					  <option value="Visa Card New"> Visa Card New </option>
                      <option value="Visa Card Repl."> Visa Card Repl. </option>
                      <option value="Visa Card Ren."> Visa Card Ren. </option>
					  <option value="QuickCash_New"> QuickCash_New </option>
                      <option value="QuickCash_Repl."> QuickCash_Repl. </option>
                      <option value="QuickCash_Ren."> QuickCash_Ren. </option>
                      <option value="Captured Cards"> Captured Cards </option>
                      <option value="Duplicate Pin"> Duplicate Pins </option>
                    </select>
		 </div>

		<div><br />
		  <input name="post[user_id]" value="<?php echo $_SESSION['user']['id']; ?>" type="hidden" />
		  &nbsp;&nbsp;&nbsp;
          <input type="submit" value="submit" />
		</div>
        <br />

 </fieldset>