<?php
	echo	
	  "<tr>
			<td>".$card['customerName']."</td>
			<td>".$card['accountNumber']."</td>
			<td>".$card['phone']."</td>
			<td>".$card['requestType']."</td>
			<td>".$card['cardType']."</td>
			<td>".$card['status']."</td>
			<td>".$card['email']."</td>
			<td>".substr($card['requestDate'],0,10)."</td>
			<td align='center'>
";

if($_SESSION['user']['accessLevel']<1)
	{ echo "
				<a href='".APP_ROOT.DS."request".DS.$card['id'].DS."approve' title='approve'>
	  				<img src='".IMG."icons/yes.gif' />
				</a> &nbsp;";
	}

	echo"
				<a href='".APP_ROOT.DS."cards/request".DS.$card['id'].DS."delete' title='delete'>
	  				<img src='".IMG."icons/no.gif' />
				</a> &nbsp;

	  			<a href='".APP_ROOT.DS."cards/request' title='OK'>
					<img src='".IMG."icons/next.gif' />
				</a>
			</td>
	   </tr>";
?>