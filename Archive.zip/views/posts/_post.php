<?php
	echo	
	  "<tr>
			<td>".$card['customerName']."</td>
			<td>".$card['accountNumber']."</td>
			<td>".$card['cardNumber']."</td>
			<td>".$card['operationType']."</td>
			<td>".$card['pickupBranch']."</td>
			<td>".$card['productionDate']."</td>
			<td>".substr($card['pickupDate'],0,10)."</td>
			<td align='center'>";
			
			if($_SESSION['user']['accessLevel']<1)
			{
				echo "<a href='".APP_ROOT.DS."cards".DS.$card['id'].DS."edit' >
						<img src='".IMG."icons/edit.gif' title='Edit' />
					  </a>";
			}
	echo 
	  "<a href='".APP_ROOT.DS."cards".DS.$card['id'].DS."edit?var=pickup' ><img src='".IMG."icons/card_found.gif' title='Pick Up' /></a>
			</td>
	   </tr>";
?>