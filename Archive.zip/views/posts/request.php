<div id="navigator">
<form action="<?php echo APP_ROOT.DS; ?>cards/request/create" onsubmit="return validateForm()" method="post" enctype="multipart/form-data" name="cardRequest" >

     <?php include('_formrequest.php');  ?> 

</form>
</div>