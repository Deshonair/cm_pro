<?php  $branches=find_branches(); ?>
 <fieldset>
   <legend>Request </legend>

<div> 
           <br /> &nbsp;&nbsp;&nbsp;
  <label> Customer Name </label>
  &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;
           <input name="post[customerName]" size="40" type="text" value="" />
		 </div>

<div> 
           <br /> &nbsp;&nbsp;&nbsp;
  <label> Account Number </label>
  &emsp;&emsp;&emsp;&emsp;&emsp;&nbsp;&nbsp;
           <input name="post[accountNumber]" size="40" maxlength="16" type="text" value="" />
		 </div>

<div> 
           <br /> &nbsp;&nbsp;&nbsp;
  <label> Mobile Number </label>
  &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&nbsp;&nbsp;
           <input name="post[phone]" size="15" type="text" value="" />
		 </div>

<div> 
           <br /> &nbsp;&nbsp;&nbsp;
  <label> Email </label>
  &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&nbsp;&nbsp;&nbsp;&nbsp;
           <input name="post[email]" size="40" type="text" value="" />
		 </div>

<div> 
           <br /> &nbsp;&nbsp;&nbsp;
  <label> Pickup Branch </label>
  &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&nbsp;&nbsp;
          <select name="post[pickupBranch]">
                      <option value=""></option>
					  <?php foreach( $branches as $post => $branch){ echo '<option value="'.$branch['branchId'].'">'.$branch['name'].' </option>';}; ?>
                    </select>
		 </div>
         
<div><br />
		   &nbsp;&nbsp;&nbsp;
           <label> Request Type </label>
  &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;
		   <select name="post[requestType]">
                      <option value=""></option>
					  <option value="New Card"> New Card </option>
                      <option value="Card Replacement"> Card Replacements </option>
                      <option value="Card Renewal"> Card Renewals </option>
                      <option value="Duplicate Pin"> Duplicate Pins </option>
                    </select>
         </div>

<div><br />
		   &nbsp;&nbsp;&nbsp;
           <label> Card Type </label>
  &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&nbsp;&nbsp
		   <select name="post[cardType]">
                      <option value=""></option>
					  <option value="visa"> VISA </option>
                      <option value="proprietary"> PROPRIETARY </option>
                    </select>
         </div>

<div><br />
		    &nbsp;&nbsp;&nbsp;
            <label> Request Date </label>
			&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;
            <input name="post[requestDate]" type="text" value="" readonly=""/>
	<script language="JavaScript">
		new tcal ({
			// form name
			'formname': 'cardRequest',
			// input name
			'controlname': 'post[requestDate]'
		});
	</script>
		 </div>


		<div><br />
		  <input name="post[user_id]" value="<?php echo $_SESSION['user']['id']; ?>" type="hidden" />
		  &nbsp;&nbsp;&nbsp;
          <input type="submit" value="submit" />
		</div>
        <br />

 </fieldset>