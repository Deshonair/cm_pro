<div id="navigator">
<form action="<?php echo APP_ROOT.DS; ?>cards/<?php echo $params['id']; ?>/update" method="post">

     <?php include('_form.php');  ?> 

</form>
</div>