<div id="navigator">
<form action="<?php echo APP_ROOT.DS; ?>cards/searchc" method="post">

     <?php include('_sform.php');  ?> 

</form>
</div>