<div id="navigator" > 
	
	<table width="100%" cellpadding="5px">
		<tr> 
			<th>Customer</th>
			<th>Account</th>
			<th>Card</th>
			<th>Request</th>
			<th>Pickup Branch</th>
			<th>Production</th>
			<th>Pickup</th>
			<th>Action</th>
		</tr>
	
	<?php

		if(!$post)
		{
			echo "Find Card Failed";
		}
		else
		{
			foreach( $post['result'] as $posts => $card){
				include('_post.php');
			}
		}
	?>
	
	
	</table>
	
		<div id="pagination" align="right">
		
			<?php if(($page - 1) <= $total_pages && $page !=1): ?> 

				<a href="<?php echo APP_ROOT.DS.$params[0].DS; ?>page/1"><img src="<?php echo IMG;?>icons/first.gif" /></a>
				<a href="<?php echo APP_ROOT.DS.$params[0].DS; ?>page/<?php echo $page - 1; ?>"><img src="<?php echo IMG;?>icons/prev.gif" title='Previous'/></a>
				
			<?php endif; ?>
			
			
			<?php if(($page + 1) <= $total_pages): ?>

				<a href="<?php echo APP_ROOT.DS.$params[0].DS; ?>page/<?php echo $page + 1; ?>"><img src="<?php echo IMG;?>icons/next.gif" /></a>
				<a href="<?php echo APP_ROOT.DS.$params[0].DS; ?>page/<?php echo $total_pages; ?>" title='last' ><img src="<?php echo IMG;?>icons/last.gif" title='next'/></a>
				<?php echo '&nbsp;&nbsp;Page&nbsp;'.$page.'&nbsp;of&nbsp;'.$total_pages ?>

			<?php endif; ?>

		</div>

</div>