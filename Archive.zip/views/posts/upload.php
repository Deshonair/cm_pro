<div id="navigator">
<form action="<?php echo APP_ROOT.DS; ?>cards/create" method="post" enctype="multipart/form-data" name="cardUpload">

     <?php include('_formupload.php');  ?> 

</form>
</div>