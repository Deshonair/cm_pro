<form action="<?php echo APP_ROOT.DS; ?>session/create" method="post">

<table width="383" align="center" cellpadding="5" background="<?php echo IMG; ?>login_bg.gif">
	<tr>
	  <td colspan="2" align='left'><img src="<?php echo IMG; ?>spacer.gif" width="30" height="164" /></td>
	  <td align='left' width="100" height="164" ><br /><br /> Use a valid username and password to gain access to the console.</td>
	  <td align='left' width="194" >
        <fieldset>  
        	<legend> Authorization </legend> <br />
            &emsp;<label> Username </label><br />
            &emsp;<label> <input name="post[username]" type="text"/> </label><br />
            &emsp;<label> Password</label><br />
            &emsp;<label> <input name="post[password]" type="password"  /> </label><br /><BR />
            &emsp;<label> <input name="submit" type="submit" value="login" /> </label><br /><br />
        </fieldset>        
      </td>
    </tr>
	<?php if(isset($_SESSION['flash']['warning']) && !$_SESSION['flash']['warning']==''){ ?>
	<tr><td colspan="4" align="center" bgcolor="#FFD8D7"><?php echo $_SESSION['flash']['warning'];?></td></tr>
    <?php } ?>

	<?php if(isset($_SESSION['flash']['notice']) && !$_SESSION['flash']['notice']==''){ ?>
	<tr><td colspan="4" align="center" bgcolor="#CFFED8"><?php echo $_SESSION['flash']['notice'];?></td></tr>
    <?php } ?>
  </table>

</form>