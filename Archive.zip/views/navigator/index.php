<table width="90%" border="0" align="center">
  <tr>
    <td><div align="center">
      <?php if($_SESSION['user']['accessLevel']<10){?>
    </div>
      <div class="img">
		  <div align="center"><a style="color:#ffffff;margin-left:20px" href="<?php echo APP_ROOT.DS;?>cards"><img src="<?php echo IMG;?>icons/cards.gif" /></a>	    </div>
		  <div class="desc"> 
			  <div align="center">VIEW CARDS </div>
		  </div>
		</div>
		<div align="center">
		  <?php } ?>
        </div></td>

    <td><div align="center">
      <?php if($_SESSION['user']['accessLevel']<10){?>
    </div>
      <div class="img">
		  <div align="center"><a style="color:#ffffff;margin-left:20px" href="<?php echo APP_ROOT.DS;?>cards/request"><img src="<?php echo IMG;?>icons/request_card.gif" /></a>	    </div>
		  <div class="desc"> 
			  <div align="center">REQUEST CARDS </div>
		  </div>
		</div>
		<div align="center">
		  <?php } ?>
        </div></td>
    <td><div align="center">
      <?php if($_SESSION['user']['accessLevel']<10){?>
    </div>
      <div class="img">
		  <div align="center"><a style="color:#ffffff;margin-left:20px" href="<?php echo APP_ROOT.DS;?>cards/search"><img src="<?php echo IMG;?>icons/search_cards.gif" /></a>	    </div>
		  <div class="desc"> 
			  <div align="center">SEARCH CARDS </div>
		  </div>
		</div>
		<div align="center">
		  <?php } ?>
        </div></td>
    <td><div align="center">
      <?php if($_SESSION['user']['accessLevel']<10){?>
    </div>
      <div class="img">
		  <div align="center"><a style="color:#ffffff;margin-left:20px" href="<?php echo APP_ROOT.DS;?>complaint"><img src="<?php echo IMG;?>icons/complaints.png" /></a>	    </div>
		  <div class="desc"> 
			  <div align="center">CUSTOMER COMPLAINTS </div>
		  </div>
		</div>
		<div align="center">
		  <?php } ?>
        </div></td>
    <td><div align="center">
      <?php if($_SESSION['user']['accessLevel']<10){?>
    </div>
      <div class="img">
		  <div align="center"><a style="color:#ffffff;margin-left:20px" href="#"><img src="<?php echo IMG;?>icons/reports.png" /></a>	    </div>
		  <div class="desc"> 
			  <div align="center">REPORTS </div>
		  </div>
		</div>
		<div align="center">
		  <?php } ?>
        </div></td>
    <td><div align="center">
      <?php if($_SESSION['user']['accessLevel']<10){?>
    </div>
      <div class="img">
		  <div align="center"><a style="color:#ffffff;margin-left:20px" href="<?php echo APP_ROOT.DS;?>atm"><img src="<?php echo IMG;?>icons/atm.gif" /></a>	    </div>
		  <div class="desc"> 
			  <div align="center">ADB ATM'S </div>
		  </div>
		</div>
		<div align="center">
		  <?php } ?>
        </div></td>
  </tr>
  <tr>
    <td><div align="center">
      <?php if($_SESSION['user']['accessLevel']<10){?>
    </div>
      <div class="img">
		  <div align="center"><a style="color:#ffffff;margin-left:20px" href="#"><img src="<?php echo IMG;?>icons/cmpro.gif" /></a>	    </div>
		  <div class="desc"> 
			  <div align="center">ABOUT CMPRO </div>
		  </div>
		</div>
		<div align="center">
		  <?php } ?>
        </div></td>
    <td><div align="center">
      <?php if($_SESSION['user']['accessLevel']<10){?>
    </div>
      <div class="img">
		  <div align="center"><a style="color:#ffffff;margin-left:20px" href="#"><img src="<?php echo IMG;?>icons/users.png" /></a>	    </div>
		  <div class="desc"> 
			  <div align="center">ADB STAFF </div>
		  </div>
		</div>
		<div align="center">
		  <?php } ?>
        </div></td>
    <td><div align="center">
      <?php if($_SESSION['user']['accessLevel']<1){?>
    </div>
      <div class="img">
		  <div align="center"><a style="color:#ffffff;margin-left:20px" href="<?php echo APP_ROOT.DS;?>cards/upload"><img src="<?php echo IMG;?>icons/card_upload.gif" /></a>	    </div>
		  <div class="desc"> 
			  <div align="center">LOAD CARDS </div>
		  </div>
		</div>
		<div align="center">
		  <?php } ?>
        </div></td>
    <td><div align="center">
      <?php if($_SESSION['user']['accessLevel']<1){?>
    </div>
      <div class="img">
		  <div align="center"><a style="color:#ffffff;margin-left:20px" href="<?php echo APP_ROOT.DS;?>branch"><img src="<?php echo IMG;?>icons/branches.png" /></a>	    </div>
		  <div class="desc"> 
			  <div align="center">ADB BRANCHES </div>
		  </div>
		</div>
		<div align="center">
		  <?php } ?>
        </div></td>
    <td><div align="center">
      <?php if($_SESSION['user']['accessLevel']<1){?>
    </div>
      <div class="img">
		  <div align="center"><a style="color:#ffffff;margin-left:20px" href="<?php echo APP_ROOT.DS;?>user"><img src="<?php echo IMG;?>icons/users_two.png" /></a>	    </div>
		  <div class="desc"> 
			  <div align="center">CMPRO USERS </div>
		  </div>
		</div>
		<div align="center">
		  <?php } ?>
        </div></td>
    <td><div align="center"></div></td>
  </tr>
</table>






