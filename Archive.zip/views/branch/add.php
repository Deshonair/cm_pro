<div id="navigator">
<form action="<?php echo APP_ROOT.DS; ?>branch/create" method="post">

     <?php include('_form.php');  ?> 

</form>
</div>