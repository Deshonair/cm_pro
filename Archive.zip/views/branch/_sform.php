<fieldset>
	<legend> Branch Search </legend>
	<div>
		<label> Search By </label>
    		<select name="post[search_by]" >
                <option value="Name">Branch Name</option>
                <option value="branchId">Branch ID</option>											
          	</select>
		<input name="post[search]" size="40" type="text" />
		<input type="submit" value="search" />
	</div>
</fieldset>