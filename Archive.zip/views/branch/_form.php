 <fieldset>
	<legend> Branch Details </legend>
	
		 <div>
			 <br /> &nbsp;&nbsp;&nbsp;
             <label> Branch ID </label> 
             &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			 <input name="post[branchId]" type="text" 
             	value="<?php if(isset($post['result'][0]['branchId'])) echo $post['result'][0]['branchId'];  ?>" size="40" <?php if($route['view']=='edit') echo 'readonly="readonly"'; ?> /> 
			</div>
	
		 <div>
			&nbsp;&nbsp;&nbsp;
            <label> Branch Name </label>
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			<input name="post[name]" type="text" value="<?php if(isset($post['result'][0]['name'])) echo $post['result'][0]['name'];  ?>" size="40" />
		 </div>
	
		 <div>
			&nbsp;&nbsp;&nbsp;
            <label> Telephone </label>
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			<input name="post[phone]" type="text" value="<?php if(isset($post['result'][0]['phone'])) echo $post['result'][0]['phone'];  ?>" size="40" />
		 </div>
	
		 <div>
			&nbsp;&nbsp;&nbsp;
            <label> Address </label>
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            <input name="post[address]" type="text" value="<?php if(isset($post['result'][0]['address'])) echo $post['result'][0]['address'];  ?>" size="40" />
		 </div>
	
		 <div>
			&nbsp;&nbsp;&nbsp;
            <label> ATM ID </label>
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            <select name="post[atmId]" >
  
                <option value=""></option>
					<?php foreach ($atms as $atm => $atm_) : ?>
                    <option value="<?php echo $atm_['atmId']; ?>"><?php echo $atm_['atmId']; ?></option>
                    <?php endforeach ?>
                                    
            </select>
		 </div><br />
			&nbsp;&nbsp;&nbsp;
            <input type="submit" value="submit" />
			<input name="post[id]" value="<?php echo $post['result'][0]['id'];  ?>" type="hidden" />
            <br /><br />
 </fieldset>