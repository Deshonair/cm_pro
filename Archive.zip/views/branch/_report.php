 <fieldset>
	<legend> Branch Card Report </legend>
	
		 <div>
			 <br /> &emsp;&emsp;
             <label> Total Card Count </label> &emsp;&emsp; <?php echo $cards_report['ccount']; ?>
		</div><br />

        <fieldset>            
                <legend> Picked Up Cards </legend>

           <table width="100%" cellpadding="5px"> 
       
               <tr> <td align='center'></td>
                <?php
            
                    if(!$cards_report['pickedup'])
                    {
                        echo "Picked Up Report Generation Failed";
                    }
                    else
                    {
                        foreach( $cards_report['pickedup'] as $posts => $branch){
                            echo	
                                  "
                                        <td align='center'>".$branch['operationtype']."</td>
                                        <td>".$branch['counts']."</td>
                                        
                                   ";
                        }
                    }
                ?>
                
                </tr>
           </table>

         </fieldset>
         
         <br />

         <fieldset>
                    
                <legend> Non Picked Up Cards </legend><div>

     <table width="100%" cellpadding="5px">        
                       <tr>
                        <?php
                    
                            if(!$cards_report['notpickedup'])
                            {
                                echo "Non Picked up Report Generation Failed";
                            }
                            else
                            {
                                foreach( $cards_report['notpickedup'] as $posts => $branch){
                                    echo	
                                          "
                                                <td align='center'>".$branch['operationtype']."</td>
                                                <td>".$branch['counts']."</td>
                                                
                                           ";
                                }
                            }
                        ?>
                        
                        </tr> 
     </table>

         </fieldset>         
 </fieldset>