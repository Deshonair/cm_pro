<div id="navigator">

     <?php include('_report.php');  ?> 

</div>