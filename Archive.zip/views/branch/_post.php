<?php
	echo	
	  "<tr>
			<td align='center'>".$branch['branchId']."</td>
			<td>".$branch['name']."</td>
			<td>".$branch['phone']."</td>
			<td>".$branch['address']."</td>
			<td>".$branch['atmId']."</td>
			<td align='center'>".substr($branch['modifiedDate'],0,10)."</td>
			<td align='center'>".substr($branch['createDate'],0,10)."</td>
			<td align='center'>
				<a href='".APP_ROOT.DS."branch".DS.$branch['id'].DS."edit' ><img src='".IMG."icons/edit.gif' /></a>
				<a href='".APP_ROOT.DS."branch".DS.$branch['id'].DS."delete' ><img src='".IMG."icons/delete.gif' /></a>
			</td>
	   </tr>";
?>