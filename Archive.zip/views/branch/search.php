<div id="navigator">
<form action="<?php echo APP_ROOT.DS; ?>branch/searchc" method="post">

     <?php include('_sform.php');  ?> 

</form>
</div>