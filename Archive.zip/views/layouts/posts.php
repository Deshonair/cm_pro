<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<title>ADB CardPro - Cards</title>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
	<link href="<?php echo CSS; ?>application.css"  rel="stylesheet" type="text/css" /> 
	<!--<link href="<?php echo CSS; ?>calender.css"  rel="stylesheet" type="text/css" /> -->
	<link rel="icon" type="image/jpg" href="<?php echo IMG;?>favicon.ico">
	<script language="JavaScript" src="<?php echo JS; ?>calendar_us.js"></script>
	
</head>

<body>
  <div id="wrapper">

		<div id="header">
			<img src="<?php echo IMG;?>cmpro_logo.gif" />
			<span class="whitefont">AGRIC DEVELOPMENT BANK 
            &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;
            &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;
            &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;
            &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;
			<?php echo $_SESSION['user']['userName']." | "; ?>
            <a href="<?php echo APP_ROOT.DS;?>session/delete">logout</a>
			</span> 
		</div>

		<!-- <div id="banner_card"></div> -->
		
		<div id="mainDisplay">
				<span>
					<a href="<?php echo APP_ROOT.DS;?>"><img src="<?php echo IMG;?>icons/home.gif" /></a>
					HOME &nbsp&nbsp&nbsp&nbsp				</span>				

					<a href="<?php echo APP_ROOT.DS;?>cards"><img src="<?php echo IMG;?>icons/allCards.gif" /></a>
				ALL CARDS &nbsp&nbsp
					<a href="<?php echo APP_ROOT.DS;?>cards/request"><img src="<?php echo IMG;?>icons/new_cards.gif" /></a> REQUEST &nbsp&nbsp				</span>		</div>
		
				<?php	include(VIEW_PATH.DS.$route['controller'].DS.$route['view'].'.php'); ?>
				
		<div id="footer">
				CMPro!. v1.2 � <?php echo date('Y',time());?> | triPOD INVENT � Privacy Policy � Terms of Service � Help
		</div>	

</div>
</body>
</html>