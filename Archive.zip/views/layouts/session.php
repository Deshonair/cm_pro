<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<title>ADB CardPro - Login</title>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
	<link href="<?php echo CSS; ?>login.css"  rel="stylesheet" type="text/css" /> 
	<link rel="icon" type="image/jpg" href="<?php echo IMG;?>favicon.ico">
</head>

<body topmargin="50px" background="../../public/images/login_bg1.gif">

    <div id="header">
        <img src="<?php echo IMG;?>cmpro_logo.gif" />
        <span class="whitefont">AGRIC DEVELOPMENT BANK</span>
    </div>
		
				<?php	include(VIEW_PATH.DS.$route['controller'].DS.$route['view'].'.php'); ?>

    <div id="footer">
        CMPro!. v1.2 � <?php echo date('Y',time());?> | triPOD INVENT � Privacy Policy � Terms of Service � Help
    </div>	
    
</body>
</html>