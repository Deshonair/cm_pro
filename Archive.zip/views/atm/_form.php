 <fieldset>
	<legend> Branch Details </legend>
	<table width="90%" border="0">
  <tr>
    <td>ATM Code</td>
    <td><input name="post[code]" type="text" 
             	value="<?php if(isset($post['result'][0]['code'])) echo $post['result'][0]['code'];  ?>" size="15" <?php if($route['view']=='edit') echo 'readonly="readonly"'; ?> /></td>
  </tr>
  <tr>
    <td>IP</td>
    <td><input name="post[ip]" type="text" value="<?php if(isset($post['result'][0]['ip'])) echo $post['result'][0]['ip'];  ?>" maxlength="15" size="15" /></td>
  </tr>
  <tr>
    <td>Comport</td>
    <td><input name="post[comport]" type="text" value="<?php if(isset($post['result'][0]['comport'])) echo $post['result'][0]['comport'];  ?>" size="15" /></td>
  </tr>
  <tr>
    <td>Branch Code</td>
    <td><input name="post[branchCode]" type="text" value="<?php if(isset($post['result'][0]['branchCode'])) echo $post['result'][0]['branchCode'];  ?>" size="15" /></td>
  </tr>
  <tr>
    <td><label> Custodian Contact </label></td>
    <td><input name="post[custodianContact]" type="text" value="<?php if(isset($post['result'][0]['custodianContact'])) echo $post['result'][0]['custodianContact'];  ?>" maxlength="10" size="15" /></td>
  </tr>
  <tr>
    <td>Install Date</td>
    <td>
	<input name="post[installDate]" type="text" value="<?php if(isset($post['result'][0]['installDate'])) echo $post['result'][0]['installDate'];  ?>" size="12" readonly="readonly" />
	<script language="JavaScript">
							new tcal ({
								// form name
								'formname': 'atm',
								// input name
								'controlname': 'post[installDate]'
							});
						</script>
	</td>
  </tr>
  <tr>
    <td><input name="post[id]" value="<?php echo $post['result'][0]['id'];  ?>" type="hidden" /></td>
    <td><input type="submit" value="submit" /></td>
  </tr>
</table>

<div>
			
			
            <br /><br />
 </fieldset>