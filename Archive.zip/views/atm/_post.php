<?php
	echo	
	  "<tr>
			<td align='center'>".$atm['code']."</td>
			<td>".$atm['code']."_".$atm['name']."</td>
			<td>".$atm['ip']."</td>
			<td>".$atm['comport']."</td>
			<td>".$atm['branchCode']."</td>
			<td align='center'>".$atm['custodianContact']."</td>
			<td align='center'>".$atm['installDate']."</td>
			<td align='center'>
				<a href='".APP_ROOT.DS."atm".DS.$atm['id'].DS."edit' ><img src='".IMG."icons/edit.gif' /></a>
				<a href='".APP_ROOT.DS."atm".DS.$atm['id'].DS."delete' ><img src='".IMG."icons/delete.gif' /></a>
			</td>
	   </tr>";
?>