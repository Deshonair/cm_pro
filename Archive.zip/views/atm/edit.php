<div id="navigator">
<form action="<?php echo APP_ROOT.DS; ?>atm/<?php echo $params['id']; ?>/update" method="post" name="atm">

     <?php include('_form.php');  ?> 

</form>
</div>