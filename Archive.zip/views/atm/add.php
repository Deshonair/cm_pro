<div id="navigator">
<form action="<?php echo APP_ROOT.DS; ?>atm/create" method="post" name="atm">

     <?php include('_form.php');  ?> 

</form>
</div>