<div id="navigator" >

	<div id="pagination" align="right">
	
		<?php if(($page - 1) <= $total_pages && $page !=1): ?> 

			<a href="<?php echo APP_ROOT.DS; ?>atm/page/1"><img src="<?php echo IMG;?>icons/first.gif" /></a>
			&nbsp;&nbsp;
			<a href="<?php echo APP_ROOT.DS; ?>atm/page/<?php echo $page - 1; ?>"><img src="<?php echo IMG;?>icons/prev.gif" /></a>
		
		<?php endif; ?>
		
		
		<?php if(($page + 1) <= $total_pages): ?>

			<a href="<?php echo APP_ROOT.DS; ?>atm/page/<?php echo $page + 1; ?>"><img src="<?php echo IMG;?>icons/next.gif" /></a>
			&nbsp;&nbsp;
			<a href="<?php echo APP_ROOT.DS; ?>atm/page/<?php echo $total_pages; ?>"><img src="<?php echo IMG;?>icons/last.gif" /></a>
			<?php echo '&nbsp;&nbsp;&nbsp;&nbsp;Page&nbsp;'.$page.'&nbsp;of&nbsp;'.$total_pages ?>

		<?php endif; ?>

	</div>

	<table width="100%" cellpadding="5px">
		<tr>
		  <th>ATM Code</th>
		  <th>Name</th>
		  <th>IP</th>
		  <th>Comport</th>
		  <th>Branch</th>
		  <th>Custodian Contach</th>
		  <th>Install Date</th>
		  <th>Action</th>
		</tr>
	
	<?php
	
	if(!$post)
	{
		echo "No ATMs Created";
	}
	else
	{
		foreach( $post['result'] as $posts => $atm){
			include('_post.php');
		}
	}
	
	?>

	</table>
	
	<div id="pagination" align="right">
	
		<?php if(($page - 1) <= $total_pages && $page !=1): ?> 

			<a href="<?php echo APP_ROOT.DS; ?>atm/page/1"><img src="<?php echo IMG;?>icons/first.gif" /></a>
			&nbsp;&nbsp;
			<a href="<?php echo APP_ROOT.DS; ?>atm/page/<?php echo $page - 1; ?>"><img src="<?php echo IMG;?>icons/prev.gif" /></a>
		
		<?php endif; ?>
		
		
		<?php if(($page + 1) <= $total_pages): ?>

			<a href="<?php echo APP_ROOT.DS; ?>atm/page/<?php echo $page + 1; ?>"><img src="<?php echo IMG;?>icons/next.gif" /></a>
			&nbsp;&nbsp;
			<a href="<?php echo APP_ROOT.DS; ?>atm/page/<?php echo $total_pages; ?>"><img src="<?php echo IMG;?>icons/last.gif" /></a>
			<?php echo '&nbsp;&nbsp;&nbsp;&nbsp;Page&nbsp;'.$page.'&nbsp;of&nbsp;'.$total_pages ?>

		<?php endif; ?>

	</div>

</div>