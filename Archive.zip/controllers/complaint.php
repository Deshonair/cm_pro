<?php
include(MODEL_PATH.DS.'complaint.php');

switch ($route['view'])
{

	case "create":
		check_authentication();
		$route['view']='showc';
		$total_pages=''; $page=1;
		$post = search_Complaint(create_Complaint($_POST['post']));
		
	break;

	case "searchc":
	 check_authentication();
	 $route['view']='show';
		   
	 $per_page = 10; 
	 $page = (isset($params['page']) && ctype_digit($params['page'])) ? $params['page'] : 1;
	 $start = $per_page * $page - $per_page;
	 $post = search_ccomplaint($_POST['post'],$start, $per_page);
	 $total_pages = ($post['num_posts'] <= $per_page) ? 1 : ceil($post['num_posts'] / $per_page);

	break;

	case "delete":
		check_authentication(1);
		
		$route['view']='complaint';
		delete_complaint( $params['id']);
		
	break;
	
	case "index":
		   
	 check_authentication();
	 $route['view']='showc';

	 $per_page = 10; 
	 $page = (isset($params['page']) && ctype_digit($params['page'])) ? $params['page'] : 1;
	 $start = $per_page * $page - $per_page;
	 $post = search_complaints($start, $per_page);
	 $total_pages = ($post['num_posts'] <= $per_page) ? 1 : ceil($post['num_posts'] / $per_page);

	break;

	case "edit":
		check_authentication();
		$post = find_card($params['id']);
		$branches = find_branches();
	break;

	case "update": 
		check_authentication();
		$route['view']='showc';
		$total_pages=''; $page=1;
		updateStatus_complaint($params['id']);
		$post = search_Complaint($params['id']);
		
	break;

	case "viewc":
	 check_authentication();
	 $route['view']='showCom';
	 $complaint = search_complaint($params['id']);

	break;

	case "updateCom": 
		check_authentication();
		$route['view']='showc';
		$total_pages=''; $page=1;
		updateComment_complaint($params['post']);
		$post = search_complaint($params['post']['id']);
		
	break;

	case "new":
		check_authentication(1);
	break;


}
?>