<?php
include(MODEL_PATH.DS.'branch.php');

switch ($route['view'])
{
	case "index":
	 check_authentication(1);	   
	 $per_page = 10; 
	 $page = (isset($params['page']) && ctype_digit($params['page'])) ? $params['page'] : 1;
	 $start = $per_page * $page - $per_page;
	 $post = find_branches($start, $per_page);
	 $total_pages = ($post['num_posts'] <= $per_page) ? 1 : ceil($post['num_posts'] / $per_page);

	break;

	case "show":
	 check_authentication(1);
	 $post = find_branch($params['id']);

	break;

	case "searchc":
	 check_authentication(1);
	 $route['view']='show';
		   
	 $per_page = 10; 
	 $page = (isset($params['page']) && ctype_digit($params['page'])) ? $params['page'] : 1;
	 $start = $per_page * $page - $per_page;
	 $post = search_branch($_POST['post'],$start, $per_page);
	 $total_pages = ($post['num_posts'] <= $per_page) ? 1 : ceil($post['num_posts'] / $per_page);

	break;

	case "edit":
		check_authentication(1);
		$post = find_branch($params['id']);
		$atms = search_atms();
	break;

	case "update": 
		check_authentication(1);
		$route['view']='show';
		update_branch($params['post']);
	break;

	case "delete":
		check_authentication(1);
		delete_branch($params['id']);
	break;

	case "add":
		check_authentication(1);
		$atms = search_atms();
	break;

	case "create":
		check_authentication(1);
		$route['view']='show';
		create_branch($params['post']);	
	break;
	
	case "report":
		check_authentication(1);
		$cards_report=fetch_cards_report();
	break;

}
?>