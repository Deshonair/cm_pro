<?php


include(MODEL_PATH.DS.'user.php');

switch ($route['view'])
{
  case "index":
	
   check_authentication(1);
   $per_page = 10; 
   $page = (isset($params['page']) && ctype_digit($params['page'])) ? $params['page'] : 1;
   $start = $per_page * $page - $per_page;
   $post = find_users($start, $per_page);
   $total_pages = ($post['num_posts'] <= $per_page) ? 1 : ceil($post['num_posts'] / $per_page);

  break;
  
  case "show":
	
   check_authentication(1);
   $post = find_user($params['id']);


  break;
  
  case "new":
	check_authentication(1);
  break;
	
  case "create":
  	check_authentication(1);
	$route['view']='show';
	create_user($params['post']);	
  break;
  
  case "edit":
	check_authentication(1);
	$post = find_user($params['id']);
	$post = $post[0];
  break;
	
  case "update":
	check_authentication(1);
	$route['view']='show';
	$post = update_user($params['post']);	
  break;
  
  case "delete":
	check_authentication(1);
	delete_user($params['id']);	
  break;

  case "aview":
    check_authentication(1);
	$per_page = 10; 
   	$page = (isset($params['page']) && ctype_digit($params['page'])) ? $params['page'] : 1;
   	$start = $per_page * $page - $per_page;
   	$post = find_auditlogs($params['id'],$start, $per_page);
   	$total_pages = ($post['num_posts'] <= $per_page) ? 1 : ceil($post['num_posts'] / $per_page);
  break;
}

?>