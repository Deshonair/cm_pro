<?php

switch ($route['view'])
{

	case "index":
		check_authentication();
	break;
}
?>