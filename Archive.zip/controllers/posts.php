<?php
include(MODEL_PATH.DS.'post.php');

switch ($route['view'])
{
	case "index":
		   
	 check_authentication();
	 $per_page = 10; 
	 $page = (isset($params['page']) && ctype_digit($params['page'])) ? $params['page'] : 1;
	 $start = $per_page * $page - $per_page;
	 $post = find_cards($start, $per_page);
	 $total_pages = ($post['num_posts'] <= $per_page) ? 1 : ceil($post['num_posts'] / $per_page);

	break;

	case "show":

	 $post = find_card($params['id']);

	 $page = null;
	 $start = null;
	 $total_pages = null;

	break;

	case "searchc":
	 check_authentication();
	 $route['view']='show';

	 $per_page = 10; 
	 $page = (isset($params['page']) && ctype_digit($params['page'])) ? $params['page'] : 1;
	 $start = $per_page * $page - $per_page;
	 $post = search_card($_POST['post'],$start, $per_page);
	 $total_pages = ($post['num_posts'] <= $per_page) ? 1 : ceil($post['num_posts'] / $per_page);

	break;

	case "rdelete":
		check_authentication(1);
		
		$route['view']='request';
		delete_cardRequest( $params['id']);
		
	break;

	case "rcreate":
		check_authentication();
		$route['view']='showr';
		
		$post = search_cardRequest(create_cardRequest($_POST['post']));
		
	break;

	case "edit":
		check_authentication();
		$post = find_card($params['id']);
		$branches = find_branches();
	break;

	case "update": 
		check_authentication();
		$route['view']='show';
		update_card($params['post']);
	break;

	case "delete":
		check_authentication(1);
	break;

	case "new":
		check_authentication(1);
	break;

	case "create":
		check_authentication(1);
		upload_card();	
	break;

	case "upload":
		check_authentication(1);
	break;
}
?>