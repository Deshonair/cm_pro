<?php
include(MODEL_PATH.DS.'atm.php');

switch ($route['view'])
{
	case "index":
	 check_authentication(1);	   
	 $per_page = 10; 
	 $page = (isset($params['page']) && ctype_digit($params['page'])) ? $params['page'] : 1;
	 $start = $per_page * $page - $per_page;
	 $post = find_atms($start, $per_page);
	 $total_pages = ($post['num_posts'] <= $per_page) ? 1 : ceil($post['num_posts'] / $per_page);

	break;

	case "show":
	 check_authentication(1);
	 $post = find_atm($params['id']);

	break;

	case "searchc":
	 check_authentication(1);
	 $route['view']='show';
		   
	 $per_page = 10; 
	 $page = (isset($params['page']) && ctype_digit($params['page'])) ? $params['page'] : 1;
	 $start = $per_page * $page - $per_page;
	 $post = search_atm($_POST['post'],$start, $per_page);
	 $total_pages = ($post['num_posts'] <= $per_page) ? 1 : ceil($post['num_posts'] / $per_page);

	break;

	case "edit":
		check_authentication(1);
		$post = find_atm($params['id']);
		//$atms = search_atms();
	break;

	case "update": 
		check_authentication(1);
		$route['view']='show';
		$post=find_atm(update_atm($params['post']));
	break;

	case "delete":
		check_authentication(1);
		delete_atm($params['id']);
	break;

	case "add":
		check_authentication(1);
	break;

	case "create":
		check_authentication(1);
		$route['view']='show';
		$post=find_atm(create_atm($params['post']));	
	break;
	
	case "report":
		check_authentication(1);
		$cards_report=fetch_cards_report();
	break;

}
?>