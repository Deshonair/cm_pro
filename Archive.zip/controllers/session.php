<?php

include(MODEL_PATH.DS.'user.php');

switch ($route['view']) {

  case "new":
    	check_authentication();
  break;

  case "create":

		if(isset($params['post']['username'],$params['post']['password']) && login($params['post']['username'], $params['post']['password']))
		{
			if($_SESSION['user']['changePassword']==1)
			{
				flash_notice('You have been logged in.');
				redirect_to('');
			}
			else
			{
				flash_notice('Reset Your Password.');
				redirect_to('session/pview');
			}
		}
		else
		{
		//flash_warning('username or password invalid');
			$route['view'] = 'index';
		}

  break;

  case "modify":

	  	if(isset($params['post']['username'],$params['post']['password']) && $params['post']['username']==$params['post']['password'] && $params['post']['password'] <> '')
		{
		  $connection = db_connect();

		  if(strlen($params['post']['password'])<6)
		  {
		  	flash_warning('Password should be 6 characters or more');
		 	$route['view'] = 'pview';
		  }
		  else
		  {
			  $cquery = "select userName from t_users where id =".$_SESSION['user']['id']." and password=password('".$params['post']['password']."')";
			  $cqresult = mysql_query($cquery);
			  
			  print_r($cquery); 
	
			  $number_of_rows = mysql_num_rows($cqresult);
	
			  
	
	
			  if(mysql_num_rows($cqresult)==0)
			  {
				$query = 	"update t_users set loginStatus=0, lastVisit = Now(), changePassword=1, password=password('".$params['post']['password']."')
							 where id =".$_SESSION['user']['id'];
				$qresult = mysql_query($query);
			  
				flash_notice('Password Reset successfully.');
				redirect_to('');
			  }
			  else
			  {
				flash_warning('New Password same as the Old Password. Please choose a different Password.');
				$route['view'] = 'pview';
			  }
	
		  }	  
		}
		else
		{
		  flash_warning('Passwordz dont match');
		  $route['view'] = 'pview';
		}

//	  $_SESSION['user'] = null;
//	  flash_notice('You have been logged out.');
//	  check_authentication();

  break;

  case "delete":

	  $connection = db_connect();
	  $query = "update t_users set loginStatus=0, lastVisit = Now() where id =".$_SESSION['user']['id'];
	  $qresult = mysql_query($query);

	  $_SESSION['user'] = null;
	  flash_notice('You have been logged out.');
	  check_authentication();

  break;

}

?>