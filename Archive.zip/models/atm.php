<?php

/**
 * Find atm
 * @param 
 * @return bool, array result, num_post;
 */

function find_atms($start = null, $per_page = null)
{
	$connection = db_connect();
	
	$query = ("select 
					a.id
					, code
					, name
					, comport
					, ip
					, branchCode
					, custodianContact
					, installDate
					, a.createDate
					, a.modifiedDate
				from	t_atm a left join t_branches b
				on		a.branchcode=b.branchid
				order by name desc"
			  );

	$qresult = mysql_query($query);	
	$number_of_posts = mysql_num_rows($qresult);

	if(isset($start) && isset($per_page))
	{
		$query .= " LIMIT $start, $per_page";		
	}			

	$qresult = mysql_query($query);	
	
	if ($number_of_posts == 0) 
	{
		return false;	
	}
	
	$atm = result_to_array($qresult);
	//return $branch; print_r($branch); exit;
	return array('result' => $atm, 'num_posts' => $number_of_posts);

}

/**
 * Find atm
 * @param 
 * @return bool, array $branches;
 */

function find_atm($params, $start = null, $per_page = null)
{
	$connection = db_connect();
	
	$query = sprintf("select 
						a.id
						, code
						, name
						, comport
						, ip
						, branchCode
						, installDate
						, custodianContact
						, a.createDate
						, a.modifiedDate
				from	t_atm a left join t_branches b
				on		a.branchcode=b.branchid
				where a.id = %s"
				, mysql_real_escape_string($params)
			  );

	$qresult = mysql_query($query);	
	$number_of_posts = mysql_num_rows($qresult);

	if(isset($start) && isset($per_page))
	{
		$query .= " LIMIT $start, $per_page";		
	}			

	$qresult = mysql_query($query);	
	
	if ($number_of_posts == 0) 
	{
		return false;	
	}
	
	$post = result_to_array($qresult);

	return array('result' => $post, 'num_posts' => $number_of_posts);

}

/**
 * Search an atm
 * @param array $params
 * @return bool, array $branch
 */

function search_atm( $params, $start = null, $per_page = null)
{
	$connection = db_connect();
	
	$query = sprintf("select 
							  id
							, code
							, name
							, comport
							, ip
							, branchCode
							, installDate
							, createDate
							, modifiedDate
					  from t_atm
					  where %s = '%s'
					  order by createDate desc"
					  , mysql_real_escape_string($params['search_by'])
					  , mysql_real_escape_string($params['search'])
				  );

	$qresult = mysql_query($query);	
	$number_of_posts = mysql_num_rows($qresult);

	if(isset($start) && isset($per_page))
	{
		$query .= " LIMIT $start, $per_page";		
	}			

	$qresult = mysql_query($query);	
	
	if ($number_of_posts == 0) 
	{
		return false;	
	}
	
	$branch = result_to_array($qresult);
	
	return array('result' => $branch, 'num_posts' => $number_of_posts);

}

/**
 * Create an atm
 * @param array $params
 * @result bool
 */

function create_atm($params)
{
	$connection = db_connect();
	
	$query = sprintf("select code from t_atm where code = %s"
					  , mysql_real_escape_string($params['code']));
	
	$qresult = mysql_query($query);	
				  	
	if( mysql_num_rows($qresult) )
	{
		exit('ATM already exist!'); return false;
	}
	else
	{
	  $query = sprintf("insert into t_atm
						  (
								 code
								, ip
								, comport
								, branchCode
								, installDate
								, custodianContact
						  )
						  values
						  (
							  '%s','%s','%s','%s','%s','%s'
						  )"
						  , mysql_real_escape_string($params['code'])
						  , mysql_real_escape_string($params['ip'])
						  , mysql_real_escape_string($params['comport'])
						  , mysql_real_escape_string($params['branchCode'])
						  , mysql_real_escape_string($params['installDate'])
						  , mysql_real_escape_string($params['custodianContact'])
					  );
	}
//print_r($query); exit('insert atm');
	$qresult = mysql_query($query);
	
	if(!$qresult)
	{
		return false;
	}
	else
	{
		return mysql_insert_id();
	}
	
}

/**
 * Update a branch
 * @param int $params
 * @return bool
 */

function update_atm($params)
{
	$connection = db_connect();
	
	
	  $query = sprintf("update t_atm 
						  set
							  comport = '%s'
							, code = '%s'
							, ip = '%s'
							, custodianContact = '%s'
							, branchCode = '%s'
							, installDate = '%s'
						  where id = %s"
						  , mysql_real_escape_string($params['comport'])
						  , mysql_real_escape_string($params['code'])
						  , mysql_real_escape_string($params['ip'])
						  , mysql_real_escape_string($params['custodianContact'])
						  , mysql_real_escape_string($params['branchCode'])
						  , mysql_real_escape_string($params['installDate'])
						  , mysql_real_escape_string($params['id'])
					);
															
	$qresult = mysql_query($query);
		
	if(!$qresult)
	{
		return false;
	}
	else
	{
		return $params['id'];
	}
	
}


/**
 * Delete an ATM
 * @param int $params
 * @return bool
 */

function delete_atm($params)
{
	$connection = db_connect();
	
	
	  $query = sprintf("delete from t_atm 
						  where id = %s"
						  , mysql_real_escape_string($params)
					);
															
	$qresult = mysql_query($query);
		
	if(!$qresult)
	{
		return false;
	}
	else
	{
		redirect_to('atm');
	}
	
}


?>