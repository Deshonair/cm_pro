<?php

/**
 * Find Atm
 * @param
 * @return bool, array $branches;
 */

function find_atms($start = null, $per_page = null)
{
	$connection = db_connect();

	$query = ("select
					a.id
					, code
					, b.name
					, comport
					, ip
					, branchCode
					, custodianContact
					, installDate
					, a.createDate
					, a.modifiedDate
				from	t_atm a left join t_branches b
				on		a.branchcode=b.branchid
				order by name desc"
			  );

	$qresult = mysql_query($query);
	$number_of_posts = mysql_num_rows($qresult);

	if(isset($start) && isset($per_page))
	{
		$query .= " LIMIT $start, $per_page";
	}

	$qresult = mysql_query($query);

	if ($number_of_posts == 0)
	{
		return false;
	}

	$atm = result_to_array($qresult);
	//return $branch; print_r($branch); exit;
	return $atm;

}

/**
 * Find branches
 * @param
 * @return bool, array $branches;
 */

function find_branches($start = null, $per_page = null)
{
	$connection = db_connect();

	$query = ("select
					id
					, name
					, branchId
					, phone
					, address
					, atmId
					, createDate
					, modifiedDate
				from t_branches
				order by name desc"
			  );

	$qresult = mysql_query($query);
	$number_of_posts = mysql_num_rows($qresult);

	$branches = result_to_array($qresult);
	return $branches;
	//return array('result' => $branches, 'num_posts' => $number_of_posts);

}


function create_complaint($params)
{
	$connection = db_connect();

	$params['cardIssueDateTime']=$params['cardComDate']." ".$params['cardTimeHr'].":".$params['cardTimeMin'].":00";
	$params['cashIssueDateTime']=$params['cashComDate']." ".$params['cashTimeHr'].":".$params['cashTimeMin'].":00";

	$query = sprintf("insert into t_complaint
										(
											customerName
											, accountNumber
											, officerName
											, complaintDate
											, cardType
											, phone
											, reportingBranch
											, customerBranch

											, cardComplaint
											, actionTaken
											, account1
											, account2
											, cardAtm
											, cardAmt
											, cardIssueDateTime

											, cashComplaint
											, customerBank
											, cashAtm
											, cashAmt
											, receiptNo
											, cashIssueDateTime

											, userId
											, comment

										)
										values
										(
										 	'%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s',
											'%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s'
										)"
										, mysql_real_escape_string($params['customerName'])
										, mysql_real_escape_string($params['accountNumber'])
										, mysql_real_escape_string($params['officerName'])
										, mysql_real_escape_string($params['complaintDate'])
										, mysql_real_escape_string($params['cardType'])
										, mysql_real_escape_string($params['phone'])
										, mysql_real_escape_string($params['reportingBranch'])
										, mysql_real_escape_string($params['customerBranch'])

										, mysql_real_escape_string($params['cardComplaint'])
										, mysql_real_escape_string($params['actionTaken'])
										, mysql_real_escape_string($params['account1'])
										, mysql_real_escape_string($params['account2'])
										, mysql_real_escape_string($params['cardAtm'])
										, mysql_real_escape_string($params['cardAmt'])
										, mysql_real_escape_string($params['cardIssueDateTime'])

										, mysql_real_escape_string($params['cashComplaint'])
										, mysql_real_escape_string($params['customerBank'])
										, mysql_real_escape_string($params['cashAtm'])
										, mysql_real_escape_string($params['cashAmt'])
										, mysql_real_escape_string($params['receiptNo'])
										, mysql_real_escape_string($params['cashIssueDateTime'])

										, mysql_real_escape_string($params['user_id'])
										, mysql_real_escape_string($params['comment'])
									);

	$qresult = mysql_query($query);
	$qresultid = mysql_insert_id();

	if(!$qresult)
	{
		return false;
	}
	else
	{
		return $qresultid;
	}

}

/**
 * Search a customer Complaint
 * @param array $params
 * @return bool, array $card
 */

function search_complaints( $start = null, $per_page = null)
{
	$connection = db_connect();

	$query = sprintf("select
						  a.id
											, customerName
											, accountNumber
											, officerName
											, complaintDate
											, cardType
											, a.phone
											, b.name reportingBranch
											, c.name customerBranch
											, a.createDate

											, cardComplaint
											, actionTaken
											, account1
											, account2
											, concat(d.code,concat('_',e.name)) cardAtm
											, cardAmt
											, cardIssueDateTime

											, cashComplaint
											, customerBank
											, cashAtm
											, cashAmt
											, receiptNo
											, cashIssueDateTime

											, userId
											, comment
											, status
					  from 	t_complaint a left join t_branches b
					  on	a.reportingBranch = b.branchId
					  left join t_branches c
					  on a.customerBranch = c.branchid
					  left join t_atm d
					  on a.cardAtm = d.code
					  left join t_branches e
					  on d.branchcode=e.branchid
					  order by a.createDate desc"
				  );

	$qresult = mysql_query($query);
	$number_of_posts = mysql_num_rows($qresult);

	if(isset($start) && isset($per_page))
	{
		$query .= " LIMIT $start, $per_page";
	}

	$qresult = mysql_query($query);

	if ($number_of_posts == 0)
	{
		return false;
	}

	$cards = result_to_array($qresult);

	return array('result' => $cards, 'num_posts' => $number_of_posts);

}

/**
 * Search a customer Complaint
 * @param array $params
 * @return bool, array $card
 */

function search_complaint( $params, $start = null, $per_page = null)
{
	$connection = db_connect();

	$query = sprintf("select
						  a.id
											, customerName
											, accountNumber
											, officerName
											, complaintDate
											, cardType
											, a.phone
											, b.name reportingBranch
											, c.name customerBranch
											, a.createDate

											, cardComplaint
											, actionTaken
											, account1
											, account2
											, concat(d.code,concat('_',e.name)) cardAtm
											, cardAmt
											, cardIssueDateTime

											, cashComplaint
											, customerBank
											, cashAtm
											, cashAmt
											, receiptNo
											, cashIssueDateTime

											, userId
											, comment
											, status
					  from 	t_complaint a left join t_branches b
					  on	a.reportingBranch = b.branchId
					  left join t_branches c
					  on a.customerBranch = c.branchid
					  left join t_atm d
					  on a.cardAtm = d.code
					  left join t_branches e
					  on d.branchcode=e.branchid
					  where a.id = '%s'
					  order by a.createDate desc"
					  , mysql_real_escape_string($params)
				  );

	$qresult = mysql_query($query);
	$number_of_posts = mysql_num_rows($qresult);

	if(isset($start) && isset($per_page))
	{
		$query .= " LIMIT $start, $per_page";
	}

	$qresult = mysql_query($query);

	if ($number_of_posts == 0)
	{
		return false;
	}

	$cards = result_to_array($qresult);

	return array('result' => $cards, 'num_posts' => $number_of_posts);

}

/**
 * Delete a Customer Complaint
 * @param array $params
 * @return bool, array $card
 */

function delete_complaint( $params )
{
	$connection = db_connect();

	$query = sprintf("delete from t_complaint where id = '%s'"
					  , mysql_real_escape_string($params)
				  );

	$qresult = mysql_query($query);

	if(!$qresult)
	{
		echo 'delete complaint failed';
		return false;
	}

}

/**
 * Update a Customer Complaint
 * @param array $params
 * @return bool, array $card
 */

function updateStatus_complaint( $params )
{
	$connection = db_connect();

	$query = sprintf("update t_complaint set status = 'RESOLVED' where id = '%s'"
					  , mysql_real_escape_string($params)
				  );

	$qresult = mysql_query($query);

	if(!$qresult)
	{
		echo 'update complaint_Status failed';
		return false;
	}

}


/**
 * Update a Customer Complaint
 * @param array $params
 * @return bool, array $card
 */

function updateComment_complaint( $params )
{
	$connection = db_connect();
	if($params['comment']<>'')
	{
	$query = sprintf("update t_complaint set comment = concat(comment,concat('<br>',concat(now(),concat('| %s >','%s')))) where id = '%s'"
					  , mysql_real_escape_string($params['userName'])
					  , mysql_real_escape_string($params['comment'])
					  , mysql_real_escape_string($params['id'])
				  );
	$qresult = mysql_query($query);
	}
	else
	{
		return true;
	}

	if(!$qresult)
	{
		echo 'update complaint_Comment failed';
		return false;
	}

}


/**
 * Search a ccomplaint
 * @param array $params
 * @return bool, array $card
 */

function search_ccomplaint( $params, $start = null, $per_page = null)
{
	$connection = db_connect();

	$query = sprintf("select
						  a.id
											, customerName
											, accountNumber
											, officerName
											, complaintDate
											, cardType
											, a.phone
											, name reportingBranch
											, customerBranch
											, a.createDate createDate

											, cardComplaint
											, actionTaken
											, account1
											, account2
											, cardAtm
											, cardAmt
											, cardIssueDateTime

											, cashComplaint
											, customerBank
											, cashAtm
											, cashAmt
											, receiptNo
											, cashIssueDateTime

											, userId
											, comment
											, status
					  from 	t_complaint a left join t_branches b
					  on	a.reportingBranch = b.branchId
					  where %s = '%s'
					  order by a.createDate desc"
					  , mysql_real_escape_string($params['search_by'])
					  , mysql_real_escape_string($params['search'])
				  );

	$qresult = mysql_query($query);
	$number_of_posts = mysql_num_rows($qresult);

	if(isset($start) && isset($per_page))
	{
		$query .= " LIMIT $start, $per_page";
	}

	$qresult = mysql_query($query);

	if ($number_of_posts == 0)
	{
		return false;
	}

	$cards = result_to_array($qresult);

	return array('result' => $cards, 'num_posts' => $number_of_posts);

}
?>