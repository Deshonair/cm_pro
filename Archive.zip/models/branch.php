<?php

/**
 * Find branches
 * @param 
 * @return bool, array result, num_post;
 */

function find_branches($start = null, $per_page = null)
{
	$connection = db_connect();
	
	$query = ("select 
					id
					, name
					, branchId
					, phone
					, address
					, atmId
					, createDate
					, modifiedDate
				from t_branches
				order by name desc"
			  );

	$qresult = mysql_query($query);	
	$number_of_posts = mysql_num_rows($qresult);

	if(isset($start) && isset($per_page))
	{
		$query .= " LIMIT $start, $per_page";		
	}			

	$qresult = mysql_query($query);	
	
	if ($number_of_posts == 0) 
	{
		return false;	
	}
	
	$branch = result_to_array($qresult);
	//return $branch; print_r($branch); exit;
	return array('result' => $branch, 'num_posts' => $number_of_posts);

}

/**
 * Find branch
 * @param 
 * @return bool, array $branches;
 */

function find_branch($params, $start = null, $per_page = null)
{
	$connection = db_connect();
	
	$query = sprintf("select 
					id
					, name
					, branchId
					, phone
					, address
					, atmId
					, createDate
					, modifiedDate
				from t_branches
				where id = %s"
				, mysql_real_escape_string($params)
			  );

	$qresult = mysql_query($query);	
	$number_of_posts = mysql_num_rows($qresult);

	if(isset($start) && isset($per_page))
	{
		$query .= " LIMIT $start, $per_page";		
	}			

	$qresult = mysql_query($query);	
	
	if ($number_of_posts == 0) 
	{
		return false;	
	}
	
	$branch = result_to_array($qresult);
	//return $branch; print_r($branch); exit;
	return array('result' => $branch, 'num_posts' => $number_of_posts);

}

/**
 * Search a Branch
 * @param array $params
 * @return bool, array $branch
 */

function search_branch( $params, $start = null, $per_page = null)
{
	$connection = db_connect();
	
	$query = sprintf("select 
						id
						, name
						, branchId
						, phone
						, address
						, atmId
						, createDate
						, modifiedDate
					  from t_branches
					  where %s = '%s'
					  order by createDate desc"
					  , mysql_real_escape_string($params['search_by'])
					  , mysql_real_escape_string($params['search'])
				  );

	$qresult = mysql_query($query);	
	$number_of_posts = mysql_num_rows($qresult);

	if(isset($start) && isset($per_page))
	{
		$query .= " LIMIT $start, $per_page";		
	}			

	$qresult = mysql_query($query);	
	
	if ($number_of_posts == 0) 
	{
		return false;	
	}
	
	$branch = result_to_array($qresult);
	
	return array('result' => $branch, 'num_posts' => $number_of_posts);

}

/**
 * Create a branch
 * @param array $params
 * @result bool
 */

function create_branch($params)
{
	$connection = db_connect();
	
	$query = sprintf("select branchId from t_branches where branchId = %s"
					  , mysql_real_escape_string($params['branchId']));
	
	$qresult = mysql_query($query);				  
	
	if(!$qresult)
	{
		exit('debug create_branch in model branch'); return false;
	}
	else
	{
	  $query = sprintf("insert into t_branches
						  (
							  name
							, branchId
							, phone
							, address
							, atmId
							, modifiedDate
						  )
						  values
						  (
							  '%s',%s,'%s','%s','%s',Now()
						  )"
						  , mysql_real_escape_string($params['name'])
						  , mysql_real_escape_string($params['branchId'])
						  , mysql_real_escape_string($params['phone'])
						  , mysql_real_escape_string($params['address'])
						  , mysql_real_escape_string($params['atmId'])
					  );
	}
															
	$qresult = mysql_query($query);
	
	if(!$qresult)
	{
		return false;
	}
	else
	{
		redirect_to('branch/'.$params['id']);
	}
	
}

/**
 * Update a branch
 * @param int $params
 * @return bool
 */

function update_branch($params)
{
	$connection = db_connect();
	
	
	  $query = sprintf("update t_branches 
						  set
							  name = '%s'
							, phone = '%s'
							, address = '%s'
							, atmId = '%s'
							, modifiedDate = Now()
						  where id = %s"
						  , mysql_real_escape_string($params['name'])
						  , mysql_real_escape_string($params['phone'])
						  , mysql_real_escape_string($params['address'])
						  , mysql_real_escape_string($params['atmId'])
						  , mysql_real_escape_string($params['id'])
					);
															
	$qresult = mysql_query($query);
		
	if(!$qresult)
	{
		return false;
	}
	else
	{
		redirect_to('branch/'.$params['id']);
	}
	
}

/**
 * Search ATMs
 * @param array $params
 * @return bool, array $atms
 */

function search_atms()
{
	$connection = db_connect();
	
	$query = ("select 
					id
					, branchCode branchId
					, code
					, Ip
					, comport
					, serviceDate
					, createDate
					, modifiedDate
				  from t_atm
				  order by createDate desc"
			  );

	$qresult = mysql_query($query);	
	$number_of_posts = mysql_num_rows($qresult);


	$atms = result_to_array($qresult);
	
	return $atms;

}

/**
 * Delete a branch
 * @param int $params
 * @return bool
 */

function delete_branch($params)
{
	$connection = db_connect();
	
	
	  $query = sprintf("delete from t_branches 
						  where id = %s"
						  , mysql_real_escape_string($params)
					);
															
	$qresult = mysql_query($query);
		
	if(!$qresult)
	{
		return false;
	}
	else
	{
		redirect_to('branch');
	}
	
}

/**
 * Report on branch cards
 * @param int $params
 * @return bool
 */

function fetch_cards_report($params = null)
{
	$connection = db_connect();
	
	  $query = ("select count(*) counts from t_cards");
															
	$qresult = mysql_query($query);
		
	if(!$qresult)
	{
		return false;
	}
	else
	{
		$card_count = mysql_fetch_row($qresult); //print_r($card_count); exit('debug: fetch_cards_count func');
		
	}

	$query = ("select operationtype, count(*) counts from t_cards where pickupDate=0 group by operationtype");
															
	$qresult = mysql_query($query);
		
	if(!$qresult)
	{
		return false;
	}
	else
	{
		$np_count = result_to_array($qresult); //print_r($card_count); exit('debug: fetch_cards_count func');
		
	}
	
	$query = ("select operationtype, count(*) counts from t_cards where pickupDate<>0 group by operationtype");
															
	$qresult = mysql_query($query);
		
	if(!$qresult)
	{
		return false;
	}
	else
	{
		$p_count = result_to_array($qresult); //print_r($card_count); exit('debug: fetch_cards_count func');
		
	}

	return array('ccount'=>$card_count[0], 'pickedup'=>$p_count, 'notpickedup'=>$np_count) ;

}

?>