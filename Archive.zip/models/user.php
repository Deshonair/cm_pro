<?php
/**
 * Find Audit User Logs
 * @param int $params
 * @return bool, array $auditlogs
 */
 
function find_auditlogs($params,$start = null, $per_page = null)
{
	$connection = db_connect();
	
	$query = sprintf("select 
				  user,
				  case
				
				   when 
					 page='/adb/session/create' and fromPage='/adb/session/new'
				   then 'Login Attempt'
				   when 
						page='/adb/session/create' and fromPage='/adb/session/create'
				   then 'Login re-attempt'
				   when 
					 page='/adb/' and frompage='/adb/session/new'
				   then 'Login Success'
				   when page='/adb/session/delete' then 'Logout Success'
				   when page='/adb/session/new' then 'Access Login'
				
				   when page='/adb/' and frompage<>'/adb/session/new'
				   then 'Access Home'
				
				   when page='/adb/cards' then 'Access Cards' 
				   when page='/adb/cards/search' then 'Search Card'
				   when page='/adb/cards/searchc' then 'Search CardResult'
				   when page='/adb/cards/upload' then 'Upload Cards'
				   when left(page,15)='/adb/cards/page' then 'Nav CardPage'
				   when left(page,10)='/adb/cards' and right(page,15)='edit?var=pickup' then 'Access PickUp'
				   when 
					 left(page,10)='/adb/cards' and right(page,6)='update' and 
					 left(fromPage,10)='/adb/cards' and right(fromPage,15)='edit?var=pickup'
				   then 'Card PickedUp'
				
				
				   when page='/adb/user' then 'Access Users'
				   when left(page,9)='/adb/user' and right(page,4)='edit'
				   then 'Edit User'
				   when left(page,9)='/adb/user' and right(page,6)='update'
				   then 'Update User'
				   when page='/adb/user/new' then 'User Create'
				   
				   else 'unknown'
				  
				  end
				  
				  action, page, fromPage, ip, visitedDate
				
				from t_tracker
				where userid = %s order by visitedDate desc"
			, mysql_real_escape_string($params)
				   );
	$qresult = mysql_query($query);
	$number_of_posts = mysql_num_rows($qresult);

	if(isset($start) && isset($per_page))
	{
		$query .= " LIMIT $start, $per_page";
	}

	$qresult = mysql_query($query);

	if ($number_of_posts == 0)
	{
		return false;
	}

	$auditlogs = result_to_array($qresult);

	return array('result' => $auditlogs, 'num_posts' => $number_of_posts);
}

/**
 * Find users
 * @param
 * @return bool, array $user
 */

function find_users($start = null, $per_page = null)
{
	$connection = db_connect();

	$query = ("select
					  id
					  , userName
					  , otherNames
					  , lastName
					  , loginStatus
					  , accessLevel
					  , lastVisit
					  , accountStatus
					  , logonDate
				  from t_users"
			  );

	$qresult = mysql_query($query);
	$number_of_posts = mysql_num_rows($qresult);

	if(isset($start) && isset($per_page))
	{
		$query .= " LIMIT $start, $per_page";
	}

	$qresult = mysql_query($query);

	if ($number_of_posts == 0)
	{
		return false;
	}

	$cards = result_to_array($qresult);

	return array('result' => $cards, 'num_posts' => $number_of_posts);

}

/**
 * Find a user
 * @param int $params
 * @return bool, array $user
 */

function find_user($params)
{
	$connection = db_connect();

	$query = sprintf("select
											id
											,userName
											, password
											, lastName
											, loginStatus
											, otherNames
											, accessLevel
											, createDate
											, modifiedDate
											, accountStatus
											, logonDate
											, lastVisit
										from t_users
										where id = %s"
										, mysql_real_escape_string($params)
									);
//echo $query; exit('find_user function');
	$qresult = mysql_query($query);
	$number_of_rows = mysql_num_rows($qresult);

	if($number_of_rows == 0)
	{
		return false;
	}
	else
	{
		$user = result_to_array($qresult); 
		return  $user;
	}

}

/**
 * Create a user
 * @param array $params
 * @result bool
 */

function create_user($params)
{
	$connection = db_connect();
	$params['password']=$params['userName'].'123';

	$query = sprintf("insert into t_users
						  (
							  userName
							  , password
							  , lastName
							  , otherNames
							  , accountStatus
							  , accessLevel
						  )
						  values
						  (
							  '%s',password('%s'),'%s','%s','%s','%s'
						  )"
						  , mysql_real_escape_string($params['userName'])
						  , mysql_real_escape_string($params['password'])
						  , mysql_real_escape_string($params['lastName'])
						  , mysql_real_escape_string($params['otherNames'])
						  , mysql_real_escape_string($params['accountStatus'])
						  , mysql_real_escape_string($params['accessLevel'])
					  );

	$qresult = mysql_query($query);
	$params['id'] = mysql_insert_id();

	if(!$qresult)
	{
		return false;
	}
	else
	{
		redirect_to('user/'.$params['id']);
	}

}

/**
 * Update a user
 * @param int $params
 * @return bool
 */

function update_user($params)
{
	$connection = db_connect();

	$query = sprintf("update t_users
							set
								userName = '%s'
							  , lastName = '%s'
							  , otherNames = '%s'
							  , accountStatus = '%s'
							  , accessLevel = '%s'
								, modifiedDate = Now()
						where id = %s"
						, mysql_real_escape_string($params['userName'])
						, mysql_real_escape_string($params['lastName'])
						, mysql_real_escape_string($params['otherNames'])
						, mysql_real_escape_string($params['accountStatus'])
						, mysql_real_escape_string($params['accessLevel'])
						, mysql_real_escape_string($params['id'])
					);

	$qresult = mysql_query($query);

	if(!$qresult)
	{
		return false;
	}
	else
	{
		redirect_to('user/'.$params['id']);
	}

}

/**
 * Returns false if invalid login else sets
 * user session and return true
 * @return bool
 */

function login($username, $password)
{
	$connection = db_connect();

	$query = sprintf("select
					  id
					  , userName
					  , otherNames
					  , lastName
					  , loginStatus
					  , accessLevel
					  , lastVisit
					  , accountStatus
					  , changePassword
				  from t_users
				  where userName='%s' ",
				  mysql_real_escape_string($username)

			  );
//print_r($query); exit('login user db check');	
	$qresult = mysql_query($query);

	@$number_of_cards = mysql_num_rows($qresult);

	if($number_of_cards == 0)
	{
		flash_warning("Account doesn't exist");
		return false;
	}

	$query = sprintf("select
					  id
					  , userName
					  , otherNames
					  , lastName
					  , loginStatus
					  , accessLevel
					  , lastVisit
					  , accountStatus
					  , changePassword
				  from t_users
				  where userName='%s' and
				        password=password('%s') ",
				  mysql_real_escape_string($username),
				  mysql_real_escape_string($password)

			  );

	$qresult = mysql_query($query);
	$number_of_cards = mysql_num_rows($qresult);

	if($number_of_cards == 0)
	{
		flash_warning("Sorry, the password you entered is not correct");
		return false;
	}


		$row = mysql_fetch_array($qresult);
		$_SESSION['user']=$row;

		if($row['accountStatus']==0)
		{
			flash_notice("Account Diabled: Contact Administrator");
			return false;
		}
		else
		{
			$query = "update t_users set loginStatus=1, logonDate=Now() where id =".$row['id'];
			$qresult = mysql_query($query);
			return true;
		}
}

/**
 * Delete a user
 * @param int $params
 * @return bool
 */
function delete_user($params)
{
	$connection = db_connect();

	$query = sprintf("delete from t_users
										where id = %s"
										, mysql_real_escape_string($params)
									);

	$qresult = mysql_query($query);

	if(!$qresult)
	{
		echo 'failed delete';
		return false;
	}
	else
	{
		redirect_to('user');
	}

}

?>