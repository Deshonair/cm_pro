<?php

/**
 * Find cards
 * @param 
 * @return bool, array $card
 */

function find_cards($start = null, $per_page = null)
{
	$connection = db_connect();

	$qresult = mysql_query("select count(1) from t_cards");	
	$number_of_posts = mysql_fetch_array($qresult);

	$query="select 
				a.id , customerName , accountNumber , cardNumber , operationType, b.name pickupBranch
				, productionDate , dispatchDate , pickupDate , batchId
			from
				(
					select
						u.id id , customerName , accountNumber , cardNumber , operationType
						, pickupBranch , productionDate , dispatchDate , pickupDate , batchId
					from
						(
							Select id from t_cards  order by createDate desc LIMIT $start, $per_page
						) t 
					join 
						t_cards u
					on	t.id=u.id
				) a 
			left join
				t_branches b
			on	a.pickupBranch=b.branchid";

	$qresult = mysql_query($query);	
	
	if ($number_of_posts[0] == 0) 
	{
		return false;	
	}
	
	$cards = result_to_array($qresult);
	
	return array('result' => $cards, 'num_posts' => $number_of_posts[0]);

}

/**
 * Find a card
 * @param int $params
 * @return bool, array $card
 */

function find_card( $params)
{
	$connection = db_connect();
	
	$query = sprintf("select 
						  	a.id id
						  ,	customerName
						  , accountNumber
						  , cardNumber
						  , operationType
						  , b.name pickupBranch
						  , productionDate
						  , dispatchDate
						  , pickupDate
						  , batchId
					  from	t_cards a left join t_branches b
					  on	a.pickupBranch = b.branchId
					  where	a.id = %s "
					  , mysql_real_escape_string($params)
				  );

	$qresult = mysql_query($query);	
	$number_of_posts = mysql_num_rows($qresult);
	
	if ($number_of_posts == 0) 
	{
		return false;	
	}
	
	$cards = result_to_array($qresult);
	
	return array('result' => $cards, 'num_posts' => $number_of_posts);
	
}

/**
 * Search a card
 * @param array $params
 * @return bool, array $card
 */

function search_card( $params, $start = null, $per_page = null)
{
	$connection = db_connect();
	
	$query = sprintf("select 
						  a.id
						  ,customerName
						  , accountNumber
						  , cardNumber
						  , operationType
						  , b.name pickupBranch
						  , productionDate
						  , dispatchDate
						  , pickupDate
						  , batchId
					  from t_cards a left join t_branches b
					  on	a.pickupBranch = b.branchId
					  where %s = '%s'
					  order by a.createDate desc"
					  , mysql_real_escape_string($params['search_by'])
					  , mysql_real_escape_string($params['search'])
				  );

	$qresult = mysql_query($query);	
	$number_of_posts = mysql_num_rows($qresult);

	if(isset($start) && isset($per_page))
	{
		$query .= " LIMIT $start, $per_page";		
	}			

	$qresult = mysql_query($query);	
	
	if ($number_of_posts == 0) 
	{
		return false;	
	}
	
	$cards = result_to_array($qresult);
	
	return array('result' => $cards, 'num_posts' => $number_of_posts);

}

/**
 * Create a card
 * @param array $params
 * @result bool
 */

function create_card($params)
{
	$connection = db_connect();
	
	$query = sprintf("insert into t_cards
										(
											customerName
											, accountNumber
											, cardNumber
											, operationType
											, productionDate
											, batchId
										)
										values
										(
										 	'%s','%s','%s','%s','%s','%s'
										)"
										, mysql_real_escape_string($params['customerName'])
										, mysql_real_escape_string($params['accountNumber'])
										, mysql_real_escape_string($params['cardNumber'])
										, mysql_real_escape_string($params['operationType'])
										, mysql_real_escape_string($params['productionDate'])
										, mysql_real_escape_string($params['batchId'])
															);
															
	$qresult = mysql_query($query);
	
	if(!$qresult)
	{
		return false;
	}
	else
	{
		return true;
	}
	
}

/**
 * Update a card
 * @param int $params
 * @return bool
 */

function update_card($params)
{
	$connection = db_connect();


	if($params['var']=="pickup")
	$query = sprintf("update t_cards 
						set
							  pickupDate = Now()
						where id = %s"
						, mysql_real_escape_string($params['id'])
				  );
	else
	$query = sprintf("update t_cards 
						set
							customerName = '%s'
							, accountNumber = '%s'
							, cardNumber = '%s'
							, pickupBranch = %s
							, productionDate = '%s'
							, dispatchDate = '%s'
							, pickupDate = '%s'
							, modifiedDate = Now()
						where id = %s"
						, mysql_real_escape_string($params['customerName'])
						, mysql_real_escape_string($params['accountNumber'])
						, mysql_real_escape_string($params['cardNumber'])
						, mysql_real_escape_string($params['pickupBranch'])
						, mysql_real_escape_string($params['productionDate'])
						, mysql_real_escape_string($params['dispatchDate'])
						, mysql_real_escape_string($params['pickupDate'])
						, mysql_real_escape_string($params['id'])
				  );
															
	$qresult = mysql_query($query);
		
	if(!$qresult)
	{
		return false;
	}
	else
	{
		redirect_to('cards/'.$params['id']);
	}
	
}


/**
 * Delete a card
 * @param int $params
 * @return bool
 */
function delete_card($params)
{
	$connection = db_connect();
	
	$query = sprintf("delete from t_cards
										where id = %s"
										, mysql_real_escape_string($params['id'])
									);
															
	$qresult = mysql_query($query);
		
	if(!$qresult)
	{
		return false;
	}
	else
	{
		return true;
	}
	
}

/**
 * Upload cards into DB and redirect to home
 */

function upload_card()
{
	$connector = db_connect();
	
	$fieldseparator = ",";
	$lineseparator = "\n";
	$csvfile = $_FILES['post']['tmp_name']['filename'];
	//$csvfile = 'sample.csv';
	$productionDate = $_POST['post']['productionDate'];
	$operationType = $_POST['post']['operationType'];
	$databasetable = 't_cards';
	$filename = '';
	$filename = $_FILES['post']['name']['filename'];

//	Check for duplicate filename
  $Dup_Filename_Check = mysql_num_rows(mysql_query("select fileName from t_filelog where fileName ='".$_FILES['post']['name']['filename']."'"));
	if($Dup_Filename_Check) {echo 'File already loaded'.$filename; exit;} 
	
	/********************************/
	/* Would you like to add an ampty field at the beginning of these records?
	/* This is useful if you have a table with the first field being an auto_increment integer
	/* and the csv file does not have such as empty field before the records.
	/* Set 1 for yes and 0 for no. ATTENTION: don't set to 1 if you are not sure.
	/* This can dump data in the wrong fields if this extra field does not exist in the table
	/********************************/
	$addauto = 1;
	/********************************/
	/* Would you like to save the mysql queries in a file? If yes set $save to 1.
	/* Permission on the file should be set to 777. Either upload a sample file through ftp and
	/* change the permissions, or execute at the prompt: touch output.sql && chmod 777 output.sql
	/********************************/
	$save = 0;
	$outputfile = "adb_output.sql";
	/********************************/
	
	
	if(!file_exists($csvfile)) {
		echo "File not found. Make sure you specified the correct path.\n";
		exit;
	}
	
	$file = fopen($csvfile,"r");
	
	if(!$file) {
		echo "Error opening data file.\n";
		exit;
	}
	
	$size = filesize($csvfile);
	
	if(!$size) {
		echo "File is empty.\n";
		exit;
	}
	
	$csvcontent = fread($file,$size);
	
	fclose($file);
	
	$lines = 0;
	$queries = "";
	$linearray = array();
	$bresult = result_to_array(mysql_query('select max(id)+1 batchno from t_filelog')); 
	
	if(is_null($bresult[0]['batchno'])){ $batchno = 1; } else { $batchno = $bresult[0]['batchno'];} 
	//echo 'batch'.$bresult[0]['batchno'].'-'.$batchno;

	foreach(split($lineseparator,$csvcontent) as $line) {
	
		$lines++;
	
		$line = trim($line," \t");
	
		$line = str_replace("\r","",$line);
	
		/************************************
		This line escapes the special character. remove it if entries are already escaped in the csv file
		************************************/
		$line = str_replace("'","\'",$line);
		/*************************************/
	
		$linearray = explode($fieldseparator,$line);
	
		$linemysql = implode("','",$linearray);
	
			$query = "insert into $databasetable(id,customerName,accountNumber,cardNumber,productionDate,operationtype,batchId) 				values('','$linemysql','$productionDate','$operationType','$batchno')";
	
	
		$queries .= $query . "\n";
	
		mysql_query($query);
	}
	$user=$_SESSION['user']['userName'];
	if ($lines > 0) { mysql_query("insert into t_filelog (id,userName,fileName,operationType)
										  values ('','$user','$filename','$operationType')"); }
	
	
	//@mysql_close($connector);
	
	if($save) {
	
		if(!is_writable($outputfile)) {
			echo "File is not writable, check permissions.\n";
		}
	
		else {
			$file2 = fopen($outputfile,"w");
	
			if(!$file2) {
				echo "Error writing to the output file.\n";
			}
			else {
				fwrite($file2,$queries);
				fclose($file2);
			}
		}
	
	}

	mysql_query("update t_cards set pickupBranch=left(ltrim(rtrim(accountNumber)),3) where pickupBranch is null");
	redirect_to('cards');
	//echo "Found a total of $lines records in this csv file.\n";

}

/**
 * Find atm
 * @param 
 * @return bool, array result, num_post;
 */

function find_atms($start = null, $per_page = null)
{
	$connection = db_connect();
	
	$query = ("select 
					a.id
					, code
					, name
					, comport
					, ip
					, branchCode
					, custodianContact
					, installDate
					, a.createDate
					, a.modifiedDate
				from	t_atm a left join t_branches b
				on		a.branchcode=b.branchid
				order by name desc"
			  );

	$qresult = mysql_query($query);	
	$number_of_posts = mysql_num_rows($qresult);

	if(isset($start) && isset($per_page))
	{
		$query .= " LIMIT $start, $per_page";		
	}			

	$qresult = mysql_query($query);	
	
	if ($number_of_posts == 0) 
	{
		return false;	
	}
	
	$atm = result_to_array($qresult);
	//return $branch; print_r($branch); exit;
	return $atm;

}

/**
 * Find branches
 * @param 
 * @return bool, array $branches;
 */

function find_branches($start = null, $per_page = null)
{
	$connection = db_connect();
	
	$query = ("select 
					id
					, name
					, branchId
					, phone
					, address
					, atmId
					, createDate
					, modifiedDate
				from t_branches
				order by name desc"
			  );

	$qresult = mysql_query($query);	
	$number_of_posts = mysql_num_rows($qresult);
	
	$branches = result_to_array($qresult);
	return $branches; 
	//return array('result' => $branches, 'num_posts' => $number_of_posts);

}

/**
 * Create a cardRequest
 * @param array $params
 * @return bool, array $card
 */

function create_cardRequest($params)
{
	$connection = db_connect();
	
	$query = sprintf("insert into t_request
										(
											customerName
											, accountNumber
											, phone
											, email
											, requestType
											, cardType
											, pickupBranch
											, userid
											, requestDate
										)
										values
										(
										 	'%s','%s','%s','%s','%s','%s','%s','%s','%s'
										)"
										, mysql_real_escape_string($params['customerName'])
										, mysql_real_escape_string($params['accountNumber'])
										, mysql_real_escape_string($params['phone'])
										, mysql_real_escape_string($params['email'])
										, mysql_real_escape_string($params['requestType'])
										, mysql_real_escape_string($params['cardType'])
										, mysql_real_escape_string($params['pickupBranch'])
										, mysql_real_escape_string($params['user_id'])
										, mysql_real_escape_string($params['requestDate'])
															);
														
	$qresult = mysql_query($query);
	$qresultid = mysql_insert_id();
	
	if(!$qresult)
	{
		return false;
	}
	else
	{
		return $qresultid;
	}
	
}

/**
 * Search a cardRequest
 * @param array $params
 * @return bool, array $card
 */

function search_cardRequest( $params, $start = null, $per_page = null)
{
	$connection = db_connect();
	
	$query = sprintf("select 
						  id
						  ,customerName
						  , accountNumber
						  , phone
						  , email
						  , requestType
						  , cardType
						  , status
						  , pickupBranch
						  , requestDate
					  from t_request
					  where id = '%s'
					  order by createDate desc"
					  , mysql_real_escape_string($params)
				  );

	$qresult = mysql_query($query);	
	$number_of_posts = mysql_num_rows($qresult);

	if(isset($start) && isset($per_page))
	{
		$query .= " LIMIT $start, $per_page";		
	}			

	$qresult = mysql_query($query);	
	
	if ($number_of_posts == 0) 
	{
		return false;	
	}
	
	$cards = result_to_array($qresult);
	
	return array('result' => $cards, 'num_posts' => $number_of_posts);

}

/**
 * Delete a cardRequest
 * @param array $params
 * @return bool, array $card
 */

function delete_cardRequest( $params )
{
	$connection = db_connect();
	
	$query = sprintf("delete from t_request where id = '%s'"
					  , mysql_real_escape_string($params)
				  );

	$qresult = mysql_query($query);

	if(!$qresult)
	{
		echo 'delete cardRequest failed';
		return false;
	}
	else
	{
		redirect_to('cards/request');
	}

}

?>