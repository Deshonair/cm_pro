<?php
/**
 * tracks visited pages
 * @param
 * @return bool
 */
 function tracker()
 {
	//collect information...
	$browser  =$_SERVER['HTTP_USER_AGENT']; // get the browser name
	$curr_page=$_SERVER['PHP_SELF'];	// get page name
	$ip  =  $_SERVER['REMOTE_ADDR'];	// get the IP address
	
	$from_page = str_replace(WEBSITE,'',@$_SERVER['HTTP_REFERER']); // page from which visitor came
	$page=$_SERVER['REQUEST_URI'];//get current page
	$user=$_SESSION['user']['userName'];
	$userid=$_SESSION['user']['id'];

	$query_insert  ="INSERT INTO t_tracker
	(browser,ip,visitedDate,page,fromPage,user,userid) VALUES
	('$browser','$ip',now(),'$page','$from_page','$user','$userid')" ;
	
	$result=mysql_query ( $query_insert); 
	if(!$result)
	{
		die(mysql_error());
	}
	
	return true;
 }


 /**
  * redirects to addess
  * @param string $address
  * @return redirects
  */
 function redirect_to($address)
 {
   header('location:'.WEBSITE.APP_ROOT.DS.$address);
   exit;
 }
 
 
 /**
  * creates warning msg used for errors.
  * @param string $msg
  * @return bool
  */
 function flash_warning($msg) 
 {
	  if(!$msg) { return false; }
	   $_SESSION['flash']['warning'] = $msg;
		return true;
 }
 
 
 /**
  * creates notice msg used for success
  * @param string $msg
  * @return bool
  */
 function flash_notice($msg) 
 {
	  if(!$msg) { return false; }
	   $_SESSION['flash']['notice'] = $_SESSION['flash']['notice']." ".$msg;
		return true;
 }

 
 /**
  * checks for user session
  * sends user to login page if session cannot be found
  * @return true or redirect
  */
  function check_authentication($param=10)
  { 

   	$connection = db_connect();

	  if(!isset($_SESSION['user']))
	  {
		  flash_warning("Sorry, you need to login!!!");
		  redirect_to('session/new');
	  }

	if(isset($_SESSION['user']) && !$_SESSION['user']=='')
	{ 
		$query = sprintf("select 
			  id
			  , userName
			  , otherNames
			  , lastName
			  , loginStatus
			  , accessLevel
			  , lastVisit
			  , accountStatus
			  , changePassword
		  from t_users
		  where userName='%s' 
		      and accountStatus =1",
		  mysql_real_escape_string($_SESSION['user']['userName'])

			  );

	$qresult = mysql_query($query);
	$number_of_cards = mysql_num_rows($qresult);
	$row = mysql_fetch_array($qresult);

	  if($number_of_cards == 0)
	  {
		  flash_warning("Sorry, Session expired. Please login again!!!");
		  redirect_to('session/new');
	  }

	  if($row['changePassword']<>1)
	  {
	  	flash_warning("Change Password");
		 redirect_to('session/pview');
	  }
	  
	  if($_SESSION['user']['accessLevel']<$param)
	  {
	  	return true;
	  }
	  else
	  {
	  	flash_warning("Sorry, You have limited Access");
		 redirect_to('');
	  }
	}
	else
	{ 	
//		session_destroy();
		redirect_to('session/new');
	}
  }

?>