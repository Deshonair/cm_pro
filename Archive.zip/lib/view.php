<?php

  /**
   * displays error msg if we have an error
   * @param bool $error
	 * @param string $msg
   * @return string
   */
  function error_msg($error, $msg)
  {
    if($error) { return $msg; }
		return '';
  }

	
  /**
   * returns the correct value for our form element
   * @param bool $error
   * @param string $row
   * @param string $param
   * @return string
   */
  function element_value($error, $row, $param)
  {
	  if ($error){ return ''; }
	  if ($row) {  return $row;  }
	  if ($param) { return $param; }
	  return '';
  }

	
  /**
   * check user session if logged in returns true
   * or else it returns false
   * @return bool
   */
  function logged_in()
  {
	  if($_SESSION['user'])
	  {
		  return true;
	  }
	  else
	  {
		return false;	
	  }
  }
  
  /**
   * returns user field
   * @param string $field;
   * @return string
   */
  function current_user($field)
  {
	return $_SESSION['user'][$field];
  }


  /**
   * format date
   * @param mysql timestamp $mysql_timestamp
   * @return string
   */
   function format_date($mysql_timestamp)
   {
	 $unix_time = strtotime($mysql_timestamp);
	   return date('M j', $unix_time);
   }

	
?>
